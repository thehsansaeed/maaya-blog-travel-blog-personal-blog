<?php
if ( post_password_required() ) {
	return;
}?>

<div id="comments" class="comments-area">
    <?php if ( have_comments() ) : ?>

	    <h3><?php comments_number(esc_html__('No Comments','maaya'), esc_html__('Comments ( 1 )','maaya'), esc_html__('Comments ( % )','maaya') ); ?></h3>

		<?php the_comments_navigation(); ?>

        <ul class="commentlist">
     		<?php wp_list_comments( array( 'callback' => 'maaya_comment_style' ) ); ?>
        </ul>

        <?php the_comments_navigation(); ?>

    <?php endif; ?>

	<?php if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) : ?>
        <p class="nocomments"><?php esc_html_e( 'Comments are closed.','maaya'); ?></p>
    <?php endif;?>    
	
    <?php

	$fields = array(
    	"author" => '<p class="comment-form-author">' . '<input id="author" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '" size="30" placeholder="' . esc_html__( 'Name', 'maaya' ) . ( $req ? ' *' : '' ) . '" /></p>',
		"email" => '<p class="comment-form-email">' . '<input id="email" name="email" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) . '" size="30" placeholder="' . esc_html__( 'Email Address', 'maaya' ) . ( $req ? ' *' : '' ) . '" /></p>',
		'url' => '<p class="comment-form-url">' . '<input id="url" name="url" type="text" value="' . esc_attr( $commenter['comment_author_url'] ) . '" size="30" placeholder="' . esc_html__( 'Website', 'maaya' ) . '" /></p>'
	);

	$comment = '<p class="comment-form-comment"><textarea id="comment" name="comment" cols="45" rows="8" aria-required="true" placeholder="' . esc_html__('Enter Your Comments Here..', 'maaya') .'">' . '</textarea></p>';
	
	if( cs_get_option('privacy-commentform') == "true" ) {
		$content = do_shortcode( cs_get_option('privacy-commentform-msg') );
		$fields['comment-form-dt-privatepolicy'] = '<p class="comment-form-dt-privatepolicy">
			<input id="comment-form-dt-privatepolicy" name="comment-form-dt-privatepolicy" type="checkbox" value="yes">
			<label for="comment-form-dt-privatepolicy">'.$content.'</label>
		</p>';
	}
	
	$comments_args = array(
		'title_reply' 			=> 	esc_html__( 'Leave a Comment','maaya' ),
		'fields'				=> 	$fields,
		'comment_field'			=> 	$comment,
		'comment_notes_before'	=>	'',
		'comment_notes_after'	=>	'<p class="comment-notes">' . esc_html__( 'Your email address will not be published. Required fields are marked *', 'maaya' ) . '</p>',
		'label_submit'			=>	esc_html__('Comment','maaya'));

	comment_form($comments_args); ?>

</div><!-- .comments-area -->