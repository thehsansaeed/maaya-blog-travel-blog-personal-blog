<?php
/**
 * Gutenberg Editor CSS
 */

if ( ! class_exists( 'Gutenberg_Editor_CSS' ) ) :

	/**
	 * Admin Helper
	 */
	class Gutenberg_Editor_CSS {

		function __construct() {

			add_action( 'current_screen', array( $this,  'maaya_current_screen_hook' ) );

			if ( class_exists( 'Classic_Editor' ) ) {
				add_filter( 'tiny_mce_before_init', array( $this, 'maaya_editor_dynamic_styles' ) );
			}
			
			add_action( 'enqueue_block_editor_assets', array( $this, 'maaya_backend_editor_styles' ) );

		}

		public function maaya_current_screen_hook( $current_screen ) {

			if ( 'post' == $current_screen->base ) {

				$urls = MAAYA_Kirki::enqueue_fonts_url();
				add_editor_style( $urls );

				add_editor_style( 'css/editor-style.css' );
	
			}
	
		}

		public function maaya_custom_font() {
			$styles = '';

			$font_name = get_theme_mod('custom-font-name',maaya_defaults('custom-font-name'));
			$woff_name = get_theme_mod('custom-font-woff',maaya_defaults('custom-font-woff'));
			$woff2_name = get_theme_mod('custom-font-woff2',maaya_defaults('custom-font-woff2'));

			if( $font_name != '' && $woff_name != '' && $woff2_name ){
				$styles .= '@font-face {';
					$styles .= "font-family: {$font_name};";
					$styles .= "src: url({$woff_name}) format('woff'),";
						$styles .= "url({$woff2_name}) format('woff2');";
					$styles .= 'font-weight: normal;';
					$styles .= 'font-style: normal;';
				$styles .= '}';

				if( get_theme_mod( 'customize-body-content-typo' ) == '0' )
					$styles .= ".editor-styles-wrapper > * { font-family:{$font_name}; }";

				for($i=1; $i<=6; $i++){

					$font = get_theme_mod('h'.$i.'',maaya_defaults('h'.$i.''));
					$font_size    	= isset($font['font-size']) ? $font['font-size'] : '';
					$font_weight  	= isset($font['variant']) ? $font['variant'] : '';
					$font_weight  	= ($font_weight == 'regular') ? '400' : $font_weight;
					$line_height    = isset($font['line-height']) ? $font['line-height'] : '';
					$letter_spacing = isset($font['letter-spacing']) ? $font['letter-spacing'] : '';
					$font_color    	= isset($font['color']) ? $font['color'] : '';
					$text_transform = isset($font['text-transform']) ? $font['text-transform'] : '';

					if( get_theme_mod( 'customize-body-'.$i.'-typo' ) == '0' ) {
				
						if($i == 1){
							$styles .= '.editor-post-title__block .editor-post-title__input, .editor-styles-wrapper .wp-block h1, body#tinymce.wp-editor.content h1 {';
						} else {
							$styles .= '.editor-styles-wrapper .wp-block h'.$i.' {';
						}

							if (!empty($font_name)) 	{   $styles .= "font-family:{$font_name};"; }
							if (!empty($font_size)) 	{ 	$styles .= "font-size:{$font_size}; "; 			}
							if (!empty($font_weight)) 	{	$styles .= "font-weight:{$font_weight}; ";		}
							if (!empty($line_height)) 	{ 	$styles .= "line-height:{$line_height}; "; 		}
							if (!empty($letter_spacing)){ 	$styles .= "letter-spacing:{$letter_spacing}; "; }	
							if (!empty($font_color)) 	{	$styles .= "color:{$font_color};";				}
							if (!empty($text_transform)){	$styles .= "text-transform:{$text_transform}; ";	}

						$styles .= '}';
					}

				}

			}

			return $styles;
		}

		public function maaya_classic_custom_font() {
			$styles = '';

			$font_name = get_theme_mod('custom-font-name',maaya_defaults('custom-font-name'));
			$woff_name = get_theme_mod('custom-font-woff',maaya_defaults('custom-font-woff'));
			$woff2_name = get_theme_mod('custom-font-woff2',maaya_defaults('custom-font-woff2'));

			if( $font_name != '' && $woff_name != '' && $woff2_name ){
				$styles .= '@font-face {';
					$styles .= "font-family: {$font_name};";
					$styles .= "src: url({$woff_name}) format('woff'),";
						$styles .= "url({$woff2_name}) format('woff2');";
					$styles .= 'font-weight: normal;';
					$styles .= 'font-style: normal;';
				$styles .= '}';

				if( get_theme_mod( 'customize-body-content-typo' ) == '0' )
					$styles .= "body#tinymce.wp-editor.content > * { font-family:{$font_name}; }";

				for($i=1; $i<=6; $i++){

					$font = get_theme_mod('h'.$i.'',maaya_defaults('h'.$i.''));
					$font_size    	= isset($font['font-size']) ? $font['font-size'] : '';
					$font_weight  	= isset($font['variant']) ? $font['variant'] : '';
					$font_weight  	= ($font_weight == 'regular') ? '400' : $font_weight;
					$line_height    = isset($font['line-height']) ? $font['line-height'] : '';
					$letter_spacing = isset($font['letter-spacing']) ? $font['letter-spacing'] : '';
					$font_color    	= isset($font['color']) ? $font['color'] : '';
					$text_transform = isset($font['text-transform']) ? $font['text-transform'] : '';

					if( get_theme_mod( 'customize-body-'.$i.'-typo' ) == '0' ) {
				
							$styles .= 'body#tinymce.wp-editor.content h'.$i.' {';

							if (!empty($font_name)) 	{   $styles .= "font-family:{$font_name};"; }
							if (!empty($font_size)) 	{ 	$styles .= "font-size:{$font_size}; "; 			}
							if (!empty($font_weight)) 	{	$styles .= "font-weight:{$font_weight}; ";		}
							if (!empty($line_height)) 	{ 	$styles .= "line-height:{$line_height}; "; 		}
							if (!empty($letter_spacing)){ 	$styles .= "letter-spacing:{$letter_spacing}; "; }	
							if (!empty($font_color)) 	{	$styles .= "color:{$font_color};";				}
							if (!empty($text_transform)){	$styles .= "text-transform:{$text_transform}; ";	}

						$styles .= '}';
					}

				}

			}

			return $styles;
		}


	
		public function maaya_editor_dynamic_styles( $mceInit ) {
	
			$styles = '';

			$styles .= $this->maaya_classic_custom_font();
			$styles .= $this->maaya_backend_classic_editor_styles();

			if ( isset( $mceInit['content_style'] ) ) {
				$mceInit['content_style'] .= ' ' . $styles . ' ';
			} else {
				$mceInit['content_style'] = $styles . ' ';
			}

			return $mceInit;
	
		}
	
		public function maaya_backend_classic_editor_styles() {
	
			$styles = '';

			$styles .= 'body#tinymce.wp-editor.content pre { font-family:monospace; }';
	
			//Body tag typography from customizer
			$status_of_body_content_typo = get_theme_mod( 'customize-body-content-typo', maaya_defaults('customize-body-content-typo') );
	
			if( $status_of_body_content_typo == '1' ) {
	
				$font = get_theme_mod('body-content-typo', maaya_defaults('body-content-typo'));
	
				$font_family    = isset($font['font-family']) ? $font['font-family'] : '';
				$font_size    	= isset($font['font-size']) ? $font['font-size'] : '';
	
				$font_weight  	= isset($font['variant']) ? $font['variant'] : '';
				$font_weight  	= ($font_weight == 'regular') ? '400' : $font_weight;
	
				$line_height    = isset($font['line-height']) ? $font['line-height'] : '';
				$letter_spacing = isset($font['letter-spacing']) ? $font['letter-spacing'] : '';
				$font_color    	= isset($font['color']) ? $font['color'] : '';
				$text_transform = isset($font['text-transform']) ? $font['text-transform'] : '';
	
				$styles .= 'body#tinymce.wp-editor.content > * {';
					if (!empty($font_family)) 	{	$styles .= "font-family:{$font_family}; ";		}
					if (!empty($font_size)) 	{ 	$styles .= "font-size:{$font_size}; "; 			}
					if (!empty($font_weight)) 	{	$styles .= "font-weight:{$font_weight}; ";		}
					if (!empty($line_height)) 	{ 	$styles .= "line-height:{$line_height}; "; 		}
					if (!empty($letter_spacing)){ 	$styles .= "letter-spacing:{$letter_spacing}; "; }	
					if (!empty($font_color)) 	{	$styles .= "color:{$font_color};";				}
					if (!empty($text_transform)){	$styles .= "text-transform:{$text_transform}; ";	}
				$styles .= "}";
	
			}
	
			//Body tag bg from customizer
			$body_bg_color = get_theme_mod('body-bg-color', maaya_defaults('body-bg-color'));
			$body_content_color = get_theme_mod('body-content-color', maaya_defaults('body-content-color'));
			$body_a_color = get_theme_mod('body-a-color', maaya_defaults('body-a-color'));
			$body_a_hover_color = get_theme_mod('body-a-hover-color', maaya_defaults('body-a-hover-color'));
			
			if (!empty($body_bg_color) || !empty($body_content_color)) {
				$styles .= 'body#tinymce.wp-editor.content {';
					if (!empty($body_bg_color))			{	$styles .= "background-color:{$body_bg_color}; ";	}
					if (!empty($body_content_color)) 	{	$styles .= "color:{$body_content_color}; ";	}
				$styles .= '}';
			}
			
			if (!empty($body_content_color)) {	
				$styles .= 'body#tinymce.wp-editor.content pre {';
					$styles .= "color:{$body_content_color}; ";
				$styles .= '}';
			}
	
			if (!empty($body_a_color)) {
				$styles .= 'body#tinymce.wp-editor.content a {';
					$styles .= "color:{$body_a_color}; ";
				$styles .= '}';
			}
	
			if (!empty($body_a_hover_color)) {
				$styles .= 'body#tinymce.wp-editor.content a:focus, body#tinymce.wp-editor.content a:hover {';
					$styles .= "color:{$body_a_hover_color}; ";
				$styles .= '}';
			}
	
			// h1 to h6 tag typography from customizer
			for ($i = 1; $i <= 6; $i++) :
				$status_of_h_typo = get_theme_mod( 'customize-body-h'.$i.'-typo', maaya_defaults('customize-body-h'.$i.'-typo') );
				if($status_of_h_typo == 1){				
					$font = get_theme_mod('h'.$i.'',maaya_defaults('h'.$i.''));
					$font_family    = isset($font['font-family']) ? $font['font-family'] : '';
					$font_size    	= isset($font['font-size']) ? $font['font-size'] : '';
	
					$font_weight  	= isset($font['variant']) ? $font['variant'] : '';
					$font_weight  	= ($font_weight == 'regular') ? '400' : $font_weight;
	
					$line_height    = isset($font['line-height']) ? $font['line-height'] : '';
					$letter_spacing = isset($font['letter-spacing']) ? $font['letter-spacing'] : '';
					$font_color    	= isset($font['color']) ? $font['color'] : '';
					$text_align    	= isset($font['text-align']) ? $font['text-align'] : '';
					$text_transform = isset($font['text-transform']) ? $font['text-transform'] : '';
	
					$styles .= 'body#tinymce.wp-editor.content h'.$i.' {';
						if (!empty($font_family)) 	{	$styles .= "font-family:{$font_family}; ";		}
						if (!empty($font_size)) 	{ 	$styles .= "font-size:{$font_size}; "; 			}
						if (!empty($font_weight)) 	{	$styles .= "font-weight:{$font_weight}; ";		}
						if (!empty($line_height)) 	{ 	$styles .= "line-height:{$line_height}; "; 		}
						else { $styles .= "line-height:normal;"; }
						if (!empty($letter_spacing)){ 	$styles .= "letter-spacing:{$letter_spacing}; "; }	
						if (!empty($font_color)) 	{	$styles .= "color:{$font_color}; ";				}
						if (!empty($text_align)) 	{	$styles .= "text-align:{$text_align}; ";			}
						if (!empty($text_transform)){	$styles .= "text-transform:{$text_transform}; ";	}
					$styles .= "}";
				}

			endfor;
	
			return $styles;
	
		}

		public function maaya_backend_editor_styles() {

			$styles = '';

			$styles .= $this->maaya_custom_font();

			$styles .= '.editor-styles-wrapper pre { font-family:monospace; }';

            $status_of_body_content_typo = get_theme_mod( 'customize-body-content-typo', maaya_defaults('customize-body-content-typo') );

            if( $status_of_body_content_typo == '1' ) {

				$font = get_theme_mod('body-content-typo', maaya_defaults('body-content-typo'));
				$line_height = isset($font['line-height']) ? $font['line-height'] : '';

				$styles .= '.wp-block-pullquote blockquote, .wp-block-pullquote blockquote p {';
					if (!empty($line_height)) { 
						$styles .= "line-height:{$line_height}; "; 
					}
				$styles .= "}";

			}

			wp_enqueue_style( 'maaya-gutenberg', get_theme_file_uri('/css/admin-gutenberg.css'), false, MAAYA_THEME_VERSION, 'all' );
			wp_add_inline_style( 'maaya-gutenberg', $styles  );

		}

	}

	new Gutenberg_Editor_CSS();

endif;