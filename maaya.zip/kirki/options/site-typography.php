<?php
$config = maaya_kirki_config();

# Custom Typography
MAAYA_Kirki::add_section( 'dt_custom_typo_section', array(
	'title' => esc_html__( 'Custom Fonts', 'maaya' ),
	'panel' => 'dt_site_typography_panel',
	'priority' => 1
) );

	# enable-custom-fonts
	MAAYA_Kirki::add_field( $config, array(
		'type'     => 'switch',
		'settings' => 'enable-custom-fonts',
		'label'    => esc_html__( 'Enable Custom Typography', 'maaya' ),
		'section'  => 'dt_custom_typo_section',
		'default'  => maaya_defaults('enable-custom-fonts'),
		'choices'  => array(
			'on'  => esc_attr__( 'Yes', 'maaya' ),
			'off' => esc_attr__( 'No', 'maaya' )
		)
	));

	#custom-font-family-name
	MAAYA_Kirki::add_field( $config, array(
		'type'     => 'text',
		'settings' => 'custom-font-name',
		'label'    => esc_html__( 'Font Family Name', 'maaya' ),
		'section'  => 'dt_custom_typo_section',
		'default'  =>  maaya_defaults('custom-font-name'),
		'active_callback' => array(
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	) );

	#custom-font-woff
	MAAYA_Kirki::add_field( $config, array(
		'type'     => 'upload',
		'settings' => 'custom-font-woff',
		'label'    => esc_html__( 'Upload File (*.woff)', 'maaya' ),
		'section'  => 'dt_custom_typo_section',
		'default'  =>  maaya_defaults('custom-font-woff'),
		'active_callback' => array(
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	) );

	#custom-font-woff2
	MAAYA_Kirki::add_field( $config, array(
		'type'     => 'upload',
		'settings' => 'custom-font-woff2',
		'label'    => esc_html__( 'Upload File (*.woff2)', 'maaya' ),
		'section'  => 'dt_custom_typo_section',
		'default'  =>  maaya_defaults('custom-font-woff2'),
		'active_callback' => array(
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	) );

# Breadcrumb Settings
MAAYA_Kirki::add_section( 'dt_site_breadcrumb_section', array(
	'title' => esc_html__( 'Breadcrumb', 'maaya' ),
	'panel' => 'dt_site_typography_panel',
	'priority' => 5
) );

	# customize-breadcrumb-title-typo
	MAAYA_Kirki::add_field( $config, array(
		'type'     => 'switch',
		'settings' => 'customize-breadcrumb-title-typo',
		'label'    => esc_html__( 'Customize Title ?', 'maaya' ),
		'section'  => 'dt_site_breadcrumb_section',
		'default'  => maaya_defaults('customize-breadcrumb-title-typo'),
		'choices'  => array(
			'on'  => esc_attr__( 'Yes', 'maaya' ),
			'off' => esc_attr__( 'No', 'maaya' )
		)			
	));
	
	# breadcrumb-title-typo
	MAAYA_Kirki::add_field( $config, array(
		'type'     => 'typography',
		'settings' => 'breadcrumb-title-typo',
		'label'    => esc_html__( 'Title Typography', 'maaya' ),
		'section'  => 'dt_site_breadcrumb_section',
		'output' => array(
			array( 'element' => '.main-title-section h1, h1.simple-title' )
		),
		'default' => maaya_defaults( 'breadcrumb-title-typo' ),
		'choices'  => array(
			'variant' => array(
				'100',
				'100italic',
				'200',
				'200italic',
				'300',
				'300italic',
				'regular',
				'italic',
				'500',
				'500italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'800',
				'800italic',
				'900',
				'900italic'
			),
		),		
		'active_callback' => array(
			array( 'setting' => 'customize-breadcrumb-title-typo', 'operator' => '==', 'value' => '1' )
		)
	));

	# custom typo fields start ----------------------------------------------------------
	MAAYA_Kirki::add_field( $config, array(
		'type'        => 'slider',
		'settings'    => 'custom-breadcrumb-title-font-size',
		'label'       => esc_attr__( 'Breadcrumb Title Font Size', 'maaya' ),
		'section'     => 'dt_site_breadcrumb_section',
		'choices'     => array(
			'min'  => '1',
			'max'  => '100',
			'step' => '1',
		),
		'default' => maaya_defaults('custom-breadcrumb-title-font-size'),
		'output' => array(
			array( 'element' => '.main-title-section h1, h1.simple-title' , 'property' => 'font-size', 'units' => 'px' )
		),
		'active_callback' => array(
			array( 'setting' => 'customize-breadcrumb-title-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));

	MAAYA_Kirki::add_field( $config, array(
		'type'        => 'select',
		'settings'    => 'custom-breadcrumb-font-weight',
		'label'       => esc_attr__( 'Breadcrumb Title Font Weight', 'maaya' ),
		'section'     => 'dt_site_breadcrumb_section',
		'choices'     => maaya_font_weights(),
		'default' 	  => 'normal',
		'output' => array(
			array( 'element' => '.main-title-section h1, h1.simple-title' , 'property' => 'font-weight' )
		),
		'active_callback' => array(
			array( 'setting' => 'customize-breadcrumb-title-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));

	MAAYA_Kirki::add_field( $config, array(
		'type'        => 'select',
		'settings'    => 'custom-breadcrumb-letter-spacing',
		'label'       => esc_attr__( 'Breadcrumb Title Letter Spacing', 'maaya' ),
		'section'     => 'dt_site_breadcrumb_section',
		'choices'     => maaya_letter_spacing(),
		'default' 	  => '0.5px',
		'output' => array(
			array( 'element' => '.main-title-section h1, h1.simple-title' , 'property' => 'letter-spacing' )
		),
		'active_callback' => array(
			array( 'setting' => 'customize-breadcrumb-title-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));

	MAAYA_Kirki::add_field( $config, array(
		'type' => 'color',
		'settings' => 'custom-breadcrumb-color',
		'label'    => esc_html__( 'Breadcrumb Title Font Color', 'maaya' ),
		'section'  => 'dt_site_breadcrumb_section',
		'output' => array(
			array( 'element' => '.main-title-section h1, h1.simple-title' , 'property' => 'color' )
		),
		'choices' => array( 'alpha' => true ),
		'default'  => maaya_defaults('custom-breadcrumb-color'),
		'active_callback' => array(
			array( 'setting' => 'customize-breadcrumb-title-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));
	# custom typo fields end ------------------------------------------------------------

	# customize-breadcrumb-typo
	MAAYA_Kirki::add_field( $config, array(
		'type'     => 'switch',
		'settings' => 'customize-breadcrumb-typo',
		'label'    => esc_html__( 'Customize Link ?', 'maaya' ),
		'section'  => 'dt_site_breadcrumb_section',
		'default'  => maaya_defaults('customize-breadcrumb-typo'),
		'choices'  => array(
			'on'  => esc_attr__( 'Yes', 'maaya' ),
			'off' => esc_attr__( 'No', 'maaya' )
		)			
	));
	
	# breadcrumb-typo
	MAAYA_Kirki::add_field( $config, array(
		'type'     => 'typography',
		'settings' => 'breadcrumb-typo',
		'label'    => esc_html__( 'Link Typography', 'maaya' ),
		'section'  => 'dt_site_breadcrumb_section',
		'output' => array(
			array( 'element' => 'div.breadcrumb a' )
		),
		'default' => maaya_defaults( 'breadcrumb-typo' ),
		'choices'  => array(
			'variant' => array(
				'100',
				'100italic',
				'200',
				'200italic',
				'300',
				'300italic',
				'regular',
				'italic',
				'500',
				'500italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'800',
				'800italic',
				'900',
				'900italic'
			),
		),
		'active_callback' => array(
			array( 'setting' => 'customize-breadcrumb-typo', 'operator' => '==', 'value' => '1' )
		)		
	));
# Breadcrumb Settings

# Body Content
MAAYA_Kirki::add_section( 'dt_body_content_typo_section', array(
	'title' => esc_html__( 'Body', 'maaya' ),
	'panel' => 'dt_site_typography_panel',
	'priority' => 15
) );

	# customize-body-content-typo
	MAAYA_Kirki::add_field( $config, array(
		'type'     => 'switch',
		'settings' => 'customize-body-content-typo',
		'label'    => esc_html__( 'Customize Content Typo', 'maaya' ),
		'section'  => 'dt_body_content_typo_section',
		'default'  => maaya_defaults( 'customize-body-content-typo' ),
		'choices'  => array(
			'on'  => esc_attr__( 'Yes', 'maaya' ),
			'off' => esc_attr__( 'No', 'maaya' )
		)
	));

	# body-content-typo
	MAAYA_Kirki::add_field( $config ,array(
		'type' => 'typography',
		'settings' => 'body-content-typo',
		'label'    => esc_html__('Settings', 'maaya'),
		'section'  => 'dt_body_content_typo_section',
		'output' => array( 
			array( 'element' => 'body' ),
			array( 
				'element' => '.editor-styles-wrapper > *',
				'context' => array ('editor')
			)
		),
		'default' => maaya_defaults('body-content-typo'),
		'choices'  => array(
			'variant' => array(
				'100',
				'100italic',
				'200',
				'200italic',
				'300',
				'300italic',
				'regular',
				'italic',
				'500',
				'500italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'800',
				'800italic',
				'900',
				'900italic'
			),
		),
		'active_callback' => array(
			array( 'setting' => 'customize-body-content-typo', 'operator' => '==', 'value' => '1' )
		)
	));

	# custom typo fields start ----------------------------------------------------------
	MAAYA_Kirki::add_field( $config, array(
		'type'        => 'slider',
		'settings'    => 'custom-body-font-size',
		'label'       => esc_attr__( 'Body Font Size', 'maaya' ),
		'section'     => 'dt_body_content_typo_section',
		'choices'     => array(
			'min'  => '1',
			'max'  => '100',
			'step' => '1',
		),
		'default' => maaya_defaults('custom-body-font-size'),
		'output' => array(
			array( 'element' => 'body' , 'property' => 'font-size', 'units' => 'px' )
		),
		'active_callback' => array(
			array( 'setting' => 'customize-body-content-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));

	MAAYA_Kirki::add_field( $config, array(
		'type'        => 'select',
		'settings'    => 'custom-body-font-weight',
		'label'       => esc_attr__( 'Body Font Weight', 'maaya' ),
		'section'     => 'dt_body_content_typo_section',
		'choices'     => maaya_font_weights(),
		'default' 	  => 'normal',
		'output' => array(
			array( 'element' => 'body' , 'property' => 'font-weight' )
		),
		'active_callback' => array(
			array( 'setting' => 'customize-body-content-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));

	MAAYA_Kirki::add_field( $config, array(
		'type'        => 'select',
		'settings'    => 'custom-body-letter-spacing',
		'label'       => esc_attr__( 'Body Letter Spacing', 'maaya' ),
		'section'     => 'dt_body_content_typo_section',
		'choices'     => maaya_letter_spacing(),
		'default' 	  => '0px',
		'output' => array(
			array( 'element' => 'body' , 'property' => 'letter-spacing' )
		),
		'active_callback' => array(
			array( 'setting' => 'customize-body-content-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));

	MAAYA_Kirki::add_field( $config, array(
		'type' => 'color',
		'settings' => 'custom-body-color',
		'label'    => esc_html__( 'Body Font Color', 'maaya' ),
		'section'  => 'dt_body_content_typo_section',
		'output' => array(
			array( 'element' => 'body' , 'property' => 'color' )
		),
		'choices' => array( 'alpha' => true ),
		'default'  => maaya_defaults('custom-body-color'),
		'active_callback' => array(
			array( 'setting' => 'customize-body-content-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));
	# custom typo fields end ------------------------------------------------------------

# Heading
MAAYA_Kirki::add_section( 'dt_headings_typo_section', array(
	'title' => esc_html__( 'Headings', 'maaya' ),
	'panel' => 'dt_site_typography_panel',
	'priority' => 20
) );

	# H1
	# customize-body-h1-typo
	MAAYA_Kirki::add_field( 'maaya_kirki_config', array(
		'type'     => 'switch',
		'settings' => 'customize-body-h1-typo',
		'label'    => esc_html__( 'Customize H1 Tag', 'maaya' ),
		'section'  => 'dt_headings_typo_section',
		'default'  => maaya_defaults( 'customize-body-h1-typo' ),
		'choices'  => array(
			'on'  => esc_attr__( 'Yes', 'maaya' ),
			'off' => esc_attr__( 'No', 'maaya' )
		)
	));

	# h1 tag typography	
	MAAYA_Kirki::add_field( 'maaya_kirki_config' ,array(
		'type' => 'typography',
		'settings' => 'h1',
		'label'    =>__('H1 Tag Settings', 'maaya'),
		'section'  => 'dt_headings_typo_section',
		'output' => array( 
			array( 'element' => 'h1' ),
			array( 
				'element' => '.editor-post-title__block .editor-post-title__input, .editor-styles-wrapper .wp-block h1, body#tinymce.wp-editor.content h1',
				'context' => array ('editor')
			),
		),
		'default' => maaya_defaults('h1'),
		'choices'  => array(
			'variant' => array(
				'100',
				'100italic',
				'200',
				'200italic',
				'300',
				'300italic',
				'regular',
				'italic',
				'500',
				'500italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'800',
				'800italic',
				'900',
				'900italic'
			),
		),					
		'active_callback' => array(
			array( 'setting' => 'customize-body-h1-typo', 'operator' => '==', 'value' => '1' )
		)
	));

	# custom typo fields start ----------------------------------------------------------
	MAAYA_Kirki::add_field( $config, array(
		'type'        => 'slider',
		'settings'    => 'custom-h1-font-size',
		'label'       => esc_attr__( 'H1 Font Size', 'maaya' ),
		'section'     => 'dt_headings_typo_section',
		'choices'     => array(
			'min'  => '1',
			'max'  => '100',
			'step' => '1',
		),
		'default' => maaya_defaults('custom-h1-font-size'),
		'output' => array(
			array( 'element' => 'h1' , 'property' => 'font-size', 'units' => 'px' )
		),
		'active_callback' => array(
			array( 'setting' => 'customize-body-h1-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));

	MAAYA_Kirki::add_field( $config, array(
		'type'        => 'select',
		'settings'    => 'custom-h1-font-weight',
		'label'       => esc_attr__( 'H1 Font Weight', 'maaya' ),
		'section'     => 'dt_headings_typo_section',
		'choices'     => maaya_font_weights(),
		'default' 	  => '300',
		'output' => array(
			array( 'element' => 'h1' , 'property' => 'font-weight' )
		),
		'active_callback' => array(
			array( 'setting' => 'customize-body-h1-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));

	MAAYA_Kirki::add_field( $config, array(
		'type'        => 'select',
		'settings'    => 'custom-h1-letter-spacing',
		'label'       => esc_attr__( 'H1 Letter Spacing', 'maaya' ),
		'section'     => 'dt_headings_typo_section',
		'choices'     => maaya_letter_spacing(),
		'default' 	  => '0.5px',
		'output' => array(
			array( 'element' => 'h1' , 'property' => 'letter-spacing' )
		),
		'active_callback' => array(
			array( 'setting' => 'customize-body-h1-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));

	MAAYA_Kirki::add_field( $config, array(
		'type' => 'color',
		'settings' => 'custom-h1-color',
		'label'    => esc_html__( 'H1 Font Color', 'maaya' ),
		'section'  => 'dt_headings_typo_section',
		'output' => array(
			array( 'element' => 'h1' , 'property' => 'color' )
		),
		'choices' => array( 'alpha' => true ),
		'default'  => maaya_defaults('custom-h1-color'),
		'active_callback' => array(
			array( 'setting' => 'customize-body-h1-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));
	# custom typo fields end ------------------------------------------------------------	

	# H1 Divider
	MAAYA_Kirki::add_field( 'maaya_kirki_config' ,array(
		'type'=> 'custom',
		'settings' => 'customize-body-h1-typo-divider',
		'section'  => 'dt_headings_typo_section',
		'default'  => '<div class="customize-control-divider"></div>'
	));

	# H2
	# customize-body-h2-typo
	MAAYA_Kirki::add_field( 'maaya_kirki_config', array(
		'type'     => 'switch',
		'settings' => 'customize-body-h2-typo',
		'label'    => esc_html__( 'Customize H2 Tag', 'maaya' ),
		'section'  => 'dt_headings_typo_section',
		'default'  => maaya_defaults( 'customize-body-h2-typo' ),
		'choices'  => array(
			'on'  => esc_attr__( 'Yes', 'maaya' ),
			'off' => esc_attr__( 'No', 'maaya' )
		)
	));

	# h2 tag typography	
	MAAYA_Kirki::add_field( 'maaya_kirki_config' ,array(
		'type' => 'typography',
		'settings' => 'h2',
		'label'    =>__('H2 Tag Settings', 'maaya'),
		'section'  => 'dt_headings_typo_section',
		'output' => array( 
			array( 'element' => 'h2' ),
			array( 
				'element' => '.editor-styles-wrapper .wp-block h2',
				'context' => array ('editor')
			),
		),
		'default' => maaya_defaults('h2'),
		'choices'  => array(
			'variant' => array(
				'100',
				'100italic',
				'200',
				'200italic',
				'300',
				'300italic',
				'regular',
				'italic',
				'500',
				'500italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'800',
				'800italic',
				'900',
				'900italic'
			),
		),									
		'active_callback' => array(
			array( 'setting' => 'customize-body-h2-typo', 'operator' => '==', 'value' => '1' )
		)
	));

	# custom typo fields start ----------------------------------------------------------
	MAAYA_Kirki::add_field( $config, array(
		'type'        => 'slider',
		'settings'    => 'custom-h2-font-size',
		'label'       => esc_attr__( 'H2 Font Size', 'maaya' ),
		'section'     => 'dt_headings_typo_section',
		'choices'     => array(
			'min'  => '1',
			'max'  => '100',
			'step' => '1',
		),
		'default' => maaya_defaults('custom-h2-font-size'),
		'output' => array(
			array( 'element' => 'h2' , 'property' => 'font-size', 'units' => 'px' )
		),
		'active_callback' => array(
			array( 'setting' => 'customize-body-h2-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));

	MAAYA_Kirki::add_field( $config, array(
		'type'        => 'select',
		'settings'    => 'custom-h2-font-weight',
		'label'       => esc_attr__( 'H2 Font Weight', 'maaya' ),
		'section'     => 'dt_headings_typo_section',
		'choices'     => maaya_font_weights(),
		'default' 	  => '300',
		'output' => array(
			array( 'element' => 'h2' , 'property' => 'font-weight' )
		),
		'active_callback' => array(
			array( 'setting' => 'customize-body-h2-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));

	MAAYA_Kirki::add_field( $config, array(
		'type'        => 'select',
		'settings'    => 'custom-h2-letter-spacing',
		'label'       => esc_attr__( 'H2 Letter Spacing', 'maaya' ),
		'section'     => 'dt_headings_typo_section',
		'choices'     => maaya_letter_spacing(),
		'default' 	  => '0.5px',
		'output' => array(
			array( 'element' => 'h2' , 'property' => 'letter-spacing' )
		),
		'active_callback' => array(
			array( 'setting' => 'customize-body-h2-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));

	MAAYA_Kirki::add_field( $config, array(
		'type' => 'color',
		'settings' => 'custom-h2-color',
		'label'    => esc_html__( 'H2 Font Color', 'maaya' ),
		'section'  => 'dt_headings_typo_section',
		'output' => array(
			array( 'element' => 'h2' , 'property' => 'color' )
		),
		'choices' => array( 'alpha' => true ),
		'default'  => maaya_defaults('custom-h2-color'),
		'active_callback' => array(
			array( 'setting' => 'customize-body-h2-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));
	# custom typo fields end ------------------------------------------------------------

	# H2 Divider
	MAAYA_Kirki::add_field( 'maaya_kirki_config' ,array(
		'type'=> 'custom',
		'settings' => 'customize-body-h2-typo-divider',
		'section'  => 'dt_headings_typo_section',
		'default'  => '<div class="customize-control-divider"></div>'
	));

	# H3
	# customize-body-h3-typo
	MAAYA_Kirki::add_field( 'maaya_kirki_config', array(
		'type'     => 'switch',
		'settings' => 'customize-body-h3-typo',
		'label'    => esc_html__( 'Customize H3 Tag', 'maaya' ),
		'section'  => 'dt_headings_typo_section',
		'default'  => maaya_defaults( 'customize-body-h3-typo' ),
		'choices'  => array(
			'on'  => esc_attr__( 'Yes', 'maaya' ),
			'off' => esc_attr__( 'No', 'maaya' )
		)
	));

	# h3 tag typography	
	MAAYA_Kirki::add_field( 'maaya_kirki_config' ,array(
		'type' => 'typography',
		'settings' => 'h3',
		'label'    =>__('H3 Tag Settings', 'maaya'),
		'section'  => 'dt_headings_typo_section',
		'output' => array( 
			array( 'element' => 'h3' ),
			array( 
				'element' => '.editor-styles-wrapper .wp-block h3',
				'context' => array ('editor')
			),
		),
		'default' => maaya_defaults('h3'),
		'choices'  => array(
			'variant' => array(
				'100',
				'100italic',
				'200',
				'200italic',
				'300',
				'300italic',
				'regular',
				'italic',
				'500',
				'500italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'800',
				'800italic',
				'900',
				'900italic'
			),
		),									
		'active_callback' => array(
			array( 'setting' => 'customize-body-h3-typo', 'operator' => '==', 'value' => '1' )
		)
	));
	
	# custom typo fields start ----------------------------------------------------------
	MAAYA_Kirki::add_field( $config, array(
		'type'        => 'slider',
		'settings'    => 'custom-h3-font-size',
		'label'       => esc_attr__( 'H3 Font Size', 'maaya' ),
		'section'     => 'dt_headings_typo_section',
		'choices'     => array(
			'min'  => '1',
			'max'  => '100',
			'step' => '1',
		),
		'default' => maaya_defaults('custom-h3-font-size'),
		'output' => array(
			array( 'element' => 'h3' , 'property' => 'font-size', 'units' => 'px' )
		),
		'active_callback' => array(
			array( 'setting' => 'customize-body-h3-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));

	MAAYA_Kirki::add_field( $config, array(
		'type'        => 'select',
		'settings'    => 'custom-h3-font-weight',
		'label'       => esc_attr__( 'H3 Font Weight', 'maaya' ),
		'section'     => 'dt_headings_typo_section',
		'choices'     => maaya_font_weights(),
		'default' 	  => '300',
		'output' => array(
			array( 'element' => 'h3' , 'property' => 'font-weight' )
		),
		'active_callback' => array(
			array( 'setting' => 'customize-body-h3-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));

	MAAYA_Kirki::add_field( $config, array(
		'type'        => 'select',
		'settings'    => 'custom-h3-letter-spacing',
		'label'       => esc_attr__( 'H3 Letter Spacing', 'maaya' ),
		'section'     => 'dt_headings_typo_section',
		'choices'     => maaya_letter_spacing(),
		'default' 	  => '0.5px',
		'output' => array(
			array( 'element' => 'h3' , 'property' => 'letter-spacing' )
		),
		'active_callback' => array(
			array( 'setting' => 'customize-body-h3-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));

	MAAYA_Kirki::add_field( $config, array(
		'type' => 'color',
		'settings' => 'custom-h3-color',
		'label'    => esc_html__( 'H3 Font Color', 'maaya' ),
		'section'  => 'dt_headings_typo_section',
		'output' => array(
			array( 'element' => 'h3' , 'property' => 'color' )
		),
		'choices' => array( 'alpha' => true ),
		'default'  => maaya_defaults('custom-h3-color'),
		'active_callback' => array(
			array( 'setting' => 'customize-body-h3-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));
	# custom typo fields end ------------------------------------------------------------

	# H3 Divider
	MAAYA_Kirki::add_field( 'maaya_kirki_config' ,array(
		'type'=> 'custom',
		'settings' => 'customize-body-h3-typo-divider',
		'section'  => 'dt_headings_typo_section',
		'default'  => '<div class="customize-control-divider"></div>'
	));

	# H4
	# customize-body-h4-typo
	MAAYA_Kirki::add_field( 'maaya_kirki_config', array(
		'type'     => 'switch',
		'settings' => 'customize-body-h4-typo',
		'label'    => esc_html__( 'Customize H4 Tag', 'maaya' ),
		'section'  => 'dt_headings_typo_section',
		'default'  => maaya_defaults( 'customize-body-h4-typo' ),
		'choices'  => array(
			'on'  => esc_attr__( 'Yes', 'maaya' ),
			'off' => esc_attr__( 'No', 'maaya' )
		)
	));

	# h4 tag typography	
	MAAYA_Kirki::add_field( 'maaya_kirki_config' ,array(
		'type' => 'typography',
		'settings' => 'h4',
		'label'    =>__('H4 Tag Settings', 'maaya'),
		'section'  => 'dt_headings_typo_section',
		'output' => array( 
			array( 'element' => 'h4' ),
			array( 
				'element' => '.editor-styles-wrapper .wp-block h4',
				'context' => array ('editor')
			),
		),
		'default' => maaya_defaults('h4'),
		'choices'  => array(
			'variant' => array(
				'100',
				'100italic',
				'200',
				'200italic',
				'300',
				'300italic',
				'regular',
				'italic',
				'500',
				'500italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'800',
				'800italic',
				'900',
				'900italic'
			),
		),									
		'active_callback' => array(
			array( 'setting' => 'customize-body-h4-typo', 'operator' => '==', 'value' => '1' )
		)
	));
	
	# custom typo fields start ----------------------------------------------------------
	MAAYA_Kirki::add_field( $config, array(
		'type'        => 'slider',
		'settings'    => 'custom-h4-font-size',
		'label'       => esc_attr__( 'H4 Font Size', 'maaya' ),
		'section'     => 'dt_headings_typo_section',
		'choices'     => array(
			'min'  => '1',
			'max'  => '100',
			'step' => '1',
		),
		'default' => maaya_defaults('custom-h4-font-size'),
		'output' => array(
			array( 'element' => 'h4' , 'property' => 'font-size', 'units' => 'px' )
		),
		'active_callback' => array(
			array( 'setting' => 'customize-body-h4-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));

	MAAYA_Kirki::add_field( $config, array(
		'type'        => 'select',
		'settings'    => 'custom-h4-font-weight',
		'label'       => esc_attr__( 'H4 Font Weight', 'maaya' ),
		'section'     => 'dt_headings_typo_section',
		'choices'     => maaya_font_weights(),
		'default' 	  => '300',
		'output' => array(
			array( 'element' => 'h4' , 'property' => 'font-weight' )
		),
		'active_callback' => array(
			array( 'setting' => 'customize-body-h4-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));

	MAAYA_Kirki::add_field( $config, array(
		'type'        => 'select',
		'settings'    => 'custom-h4-letter-spacing',
		'label'       => esc_attr__( 'H4 Letter Spacing', 'maaya' ),
		'section'     => 'dt_headings_typo_section',
		'choices'     => maaya_letter_spacing(),
		'default' 	  => '0.5px',
		'output' => array(
			array( 'element' => 'h4' , 'property' => 'letter-spacing' )
		),
		'active_callback' => array(
			array( 'setting' => 'customize-body-h4-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));

	MAAYA_Kirki::add_field( $config, array(
		'type' => 'color',
		'settings' => 'custom-h4-color',
		'label'    => esc_html__( 'H4 Font Color', 'maaya' ),
		'section'  => 'dt_headings_typo_section',
		'output' => array(
			array( 'element' => 'h4' , 'property' => 'color' )
		),
		'choices' => array( 'alpha' => true ),
		'default'  => maaya_defaults('custom-h4-color'),
		'active_callback' => array(
			array( 'setting' => 'customize-body-h4-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));
	# custom typo fields end ------------------------------------------------------------

	# H4 Divider
	MAAYA_Kirki::add_field( 'maaya_kirki_config' ,array(
		'type'=> 'custom',
		'settings' => 'customize-body-h4-typo-divider',
		'section'  => 'dt_headings_typo_section',
		'default'  => '<div class="customize-control-divider"></div>'
	));

	# H5
	# customize-body-h5-typo
	MAAYA_Kirki::add_field( 'maaya_kirki_config', array(
		'type'     => 'switch',
		'settings' => 'customize-body-h5-typo',
		'label'    => esc_html__( 'Customize H5 Tag', 'maaya' ),
		'section'  => 'dt_headings_typo_section',
		'default'  => maaya_defaults( 'customize-body-h5-typo' ),
		'choices'  => array(
			'on'  => esc_attr__( 'Yes', 'maaya' ),
			'off' => esc_attr__( 'No', 'maaya' )
		)
	));

	# h5 tag typography	
	MAAYA_Kirki::add_field( 'maaya_kirki_config' ,array(
		'type' => 'typography',
		'settings' => 'h5',
		'label'    =>__('H5 Tag Settings', 'maaya'),
		'section'  => 'dt_headings_typo_section',
		'output' => array( 
			array( 'element' => 'h5' ),
			array( 
				'element' => '.editor-styles-wrapper .wp-block h5',
				'context' => array ('editor')
			),
		),
		'default' => maaya_defaults('h5'),
		'choices'  => array(
			'variant' => array(
				'100',
				'100italic',
				'200',
				'200italic',
				'300',
				'300italic',
				'regular',
				'italic',
				'500',
				'500italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'800',
				'800italic',
				'900',
				'900italic'
			),
		),									
		'active_callback' => array(
			array( 'setting' => 'customize-body-h5-typo', 'operator' => '==', 'value' => '1' )
		)
	));

	# custom typo fields start ----------------------------------------------------------
	MAAYA_Kirki::add_field( $config, array(
		'type'        => 'slider',
		'settings'    => 'custom-h5-font-size',
		'label'       => esc_attr__( 'H5 Font Size', 'maaya' ),
		'section'     => 'dt_headings_typo_section',
		'choices'     => array(
			'min'  => '1',
			'max'  => '100',
			'step' => '1',
		),
		'default' => maaya_defaults('custom-h5-font-size'),
		'output' => array(
			array( 'element' => 'h5' , 'property' => 'font-size', 'units' => 'px' )
		),
		'active_callback' => array(
			array( 'setting' => 'customize-body-h5-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));

	MAAYA_Kirki::add_field( $config, array(
		'type'        => 'select',
		'settings'    => 'custom-h5-font-weight',
		'label'       => esc_attr__( 'H5 Font Weight', 'maaya' ),
		'section'     => 'dt_headings_typo_section',
		'choices'     => maaya_font_weights(),
		'default' 	  => '300',
		'output' => array(
			array( 'element' => 'h5' , 'property' => 'font-weight' )
		),
		'active_callback' => array(
			array( 'setting' => 'customize-body-h5-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));

	MAAYA_Kirki::add_field( $config, array(
		'type'        => 'select',
		'settings'    => 'custom-h5-letter-spacing',
		'label'       => esc_attr__( 'H5 Letter Spacing', 'maaya' ),
		'section'     => 'dt_headings_typo_section',
		'choices'     => maaya_letter_spacing(),
		'default' 	  => '0.5px',
		'output' => array(
			array( 'element' => 'h5' , 'property' => 'letter-spacing' )
		),
		'active_callback' => array(
			array( 'setting' => 'customize-body-h5-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));

	MAAYA_Kirki::add_field( $config, array(
		'type' => 'color',
		'settings' => 'custom-h5-color',
		'label'    => esc_html__( 'H5 Font Color', 'maaya' ),
		'section'  => 'dt_headings_typo_section',
		'output' => array(
			array( 'element' => 'h5' , 'property' => 'color' )
		),
		'choices' => array( 'alpha' => true ),
		'default'  => maaya_defaults('custom-h5-color'),
		'active_callback' => array(
			array( 'setting' => 'customize-body-h5-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));
	# custom typo fields end ------------------------------------------------------------	

	# H5 Divider
	MAAYA_Kirki::add_field( 'maaya_kirki_config' ,array(
		'type'=> 'custom',
		'settings' => 'customize-body-h5-typo-divider',
		'section'  => 'dt_headings_typo_section',
		'default'  => '<div class="customize-control-divider"></div>'
	));

	# H6
	# customize-body-h6-typo
	MAAYA_Kirki::add_field( 'maaya_kirki_config', array(
		'type'     => 'switch',
		'settings' => 'customize-body-h6-typo',
		'label'    => esc_html__( 'Customize H6 Tag', 'maaya' ),
		'section'  => 'dt_headings_typo_section',
		'default'  => maaya_defaults( 'customize-body-h6-typo' ),
		'choices'  => array(
			'on'  => esc_attr__( 'Yes', 'maaya' ),
			'off' => esc_attr__( 'No', 'maaya' )
		)
	));

	# h6 tag typography	
	MAAYA_Kirki::add_field( 'maaya_kirki_config' ,array(
		'type' => 'typography',
		'settings' => 'h6',
		'label'    =>__('H6 Tag Settings', 'maaya'),
		'section'  => 'dt_headings_typo_section',
		'output' => array( 
			array( 'element' => 'h6' ),
			array( 
				'element' => '.editor-styles-wrapper .wp-block h6',
				'context' => array ('editor')
			),
		),
		'default' => maaya_defaults('h6'),
		'choices'  => array(
			'variant' => array(
				'100',
				'100italic',
				'200',
				'200italic',
				'300',
				'300italic',
				'regular',
				'italic',
				'500',
				'500italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'800',
				'800italic',
				'900',
				'900italic'
			),
		),									
		'active_callback' => array(
			array( 'setting' => 'customize-body-h6-typo', 'operator' => '==', 'value' => '1' )
		)
	));

	# custom typo fields start ----------------------------------------------------------
	MAAYA_Kirki::add_field( $config, array(
		'type'        => 'slider',
		'settings'    => 'custom-h6-font-size',
		'label'       => esc_attr__( 'H6 Font Size', 'maaya' ),
		'section'     => 'dt_headings_typo_section',
		'choices'     => array(
			'min'  => '1',
			'max'  => '100',
			'step' => '1',
		),
		'default' => maaya_defaults('custom-h6-font-size'),
		'output' => array(
			array( 'element' => 'h6' , 'property' => 'font-size', 'units' => 'px' )
		),
		'active_callback' => array(
			array( 'setting' => 'customize-body-h6-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));

	MAAYA_Kirki::add_field( $config, array(
		'type'        => 'select',
		'settings'    => 'custom-h6-font-weight',
		'label'       => esc_attr__( 'H6 Font Weight', 'maaya' ),
		'section'     => 'dt_headings_typo_section',
		'choices'     => maaya_font_weights(),
		'default' 	  => '300',
		'output' => array(
			array( 'element' => 'h6' , 'property' => 'font-weight' )
		),
		'active_callback' => array(
			array( 'setting' => 'customize-body-h6-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));

	MAAYA_Kirki::add_field( $config, array(
		'type'        => 'select',
		'settings'    => 'custom-h6-letter-spacing',
		'label'       => esc_attr__( 'H6 Letter Spacing', 'maaya' ),
		'section'     => 'dt_headings_typo_section',
		'choices'     => maaya_letter_spacing(),
		'default' 	  => '0.5px',
		'output' => array(
			array( 'element' => 'h6' , 'property' => 'letter-spacing' )
		),
		'active_callback' => array(
			array( 'setting' => 'customize-body-h6-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));

	MAAYA_Kirki::add_field( $config, array(
		'type' => 'color',
		'settings' => 'custom-h6-color',
		'label'    => esc_html__( 'H6 Font Color', 'maaya' ),
		'section'  => 'dt_headings_typo_section',
		'output' => array(
			array( 'element' => 'h6' , 'property' => 'color' )
		),
		'choices' => array( 'alpha' => true ),
		'default'  => maaya_defaults('custom-h6-color'),
		'active_callback' => array(
			array( 'setting' => 'customize-body-h6-typo', 'operator' => '==', 'value' => '0' ),
			array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
		)
	));
	# custom typo fields end ------------------------------------------------------------

# Footer Typography
	MAAYA_Kirki::add_section( 'dt_footer_typo', array(
		'title'	=> esc_html__( 'Footer', 'maaya' ),
		'panel' => 'dt_site_typography_panel',
		'priority' => 100,
	) );

		# customize-footer-title-typo
		MAAYA_Kirki::add_field( $config, array(
			'type'     => 'switch',
			'settings' => 'customize-footer-title-typo',
			'label'    => esc_html__( 'Customize Title ?', 'maaya' ),
			'section'  => 'dt_footer_typo',
			'default'  => maaya_defaults('customize-footer-title-typo'),
			'choices'  => array(
				'on'  => esc_attr__( 'Yes', 'maaya' ),
				'off' => esc_attr__( 'No', 'maaya' )
			),
		));

		# footer-title-typo
		MAAYA_Kirki::add_field( $config, array(
			'type'     => 'typography',
			'settings' => 'footer-title-typo',
			'label'    => esc_html__( 'Title Typography', 'maaya' ),
			'section'  => 'dt_footer_typo',
			'output' => array(
				array( 'element' => 'div.footer-widgets h3.widgettitle' )
			),
			'default' => maaya_defaults( 'footer-title-typo' ),
			'active_callback' => array(
				array( 'setting' => 'customize-footer-title-typo', 'operator' => '==', 'value' => '1' )
			)
		));

		# custom typo fields start ----------------------------------------------------------
		MAAYA_Kirki::add_field( $config, array(
			'type'        => 'slider',
			'settings'    => 'custom-footer-title-font-size',
			'label'       => esc_attr__( 'Footer Title Font Size', 'maaya' ),
			'section'     => 'dt_footer_typo',
			'choices'     => array(
				'min'  => '1',
				'max'  => '100',
				'step' => '1',
			),
			'default' => maaya_defaults('custom-footer-title-font-size'),
			'output' => array(
				array( 'element' => 'div.footer-widgets h3.widgettitle' , 'property' => 'font-size', 'units' => 'px' )
			),
			'active_callback' => array(
				array( 'setting' => 'customize-footer-title-typo', 'operator' => '==', 'value' => '0' ),
				array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
			)
		));

		MAAYA_Kirki::add_field( $config, array(
			'type'        => 'select',
			'settings'    => 'custom-footer-title-font-weight',
			'label'       => esc_attr__( 'Footer Title Font Weight', 'maaya' ),
			'section'     => 'dt_footer_typo',
			'choices'     => maaya_font_weights(),
			'default' 	  => '700',
			'output' => array(
				array( 'element' => 'div.footer-widgets h3.widgettitle' , 'property' => 'font-weight' )
			),
			'active_callback' => array(
				array( 'setting' => 'customize-footer-title-typo', 'operator' => '==', 'value' => '0' ),
				array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
			)
		));

		MAAYA_Kirki::add_field( $config, array(
			'type'        => 'select',
			'settings'    => 'custom-footer-title-letter-spacing',
			'label'       => esc_attr__( 'Footer Title Letter Spacing', 'maaya' ),
			'section'     => 'dt_footer_typo',
			'choices'     => maaya_letter_spacing(),
			'default' 	  => '0px',
			'output' => array(
				array( 'element' => 'div.footer-widgets h3.widgettitle' , 'property' => 'letter-spacing' )
			),
			'active_callback' => array(
				array( 'setting' => 'customize-footer-title-typo', 'operator' => '==', 'value' => '0' ),
				array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
			)
		));

		MAAYA_Kirki::add_field( $config, array(
			'type' => 'color',
			'settings' => 'custom-footer-title-color',
			'label'    => esc_html__( 'Footer Title Font Color', 'maaya' ),
			'section'  => 'dt_footer_typo',
			'output' => array(
				array( 'element' => 'div.footer-widgets h3.widgettitle' , 'property' => 'color' )
			),
			'choices' => array( 'alpha' => true ),
			'default'  => maaya_defaults('custom-footer-title-color'),
			'active_callback' => array(
				array( 'setting' => 'customize-footer-title-typo', 'operator' => '==', 'value' => '0' ),
				array( 'setting' => 'enable-custom-fonts', 'operator' => '==', 'value' => '1' )
			)
		));
		# custom typo fields end ------------------------------------------------------------

		# Divider
		MAAYA_Kirki::add_field( $config ,array(
			'type'=> 'custom',
			'settings' => 'footer-title-typo-divider',
			'section'  => 'dt_footer_typo',
			'default'  => '<div class="customize-control-divider"></div>',
			'active_callback' => array(
				array( 'setting' => 'customize-footer-title-typo', 'operator' => '==', 'value' => '1' )
			)			
		));

		# customize-footer-content-typo
		MAAYA_Kirki::add_field( $config, array(
			'type'     => 'switch',
			'settings' => 'customize-footer-content-typo',
			'label'    => esc_html__( 'Customize Content ?', 'maaya' ),
			'section'  => 'dt_footer_typo',
			'default'  => maaya_defaults('customize-footer-content-typo'),
			'choices'  => array(
				'on'  => esc_attr__( 'Yes', 'maaya' ),
				'off' => esc_attr__( 'No', 'maaya' )
			),
		));

		# footer-content-typo
		MAAYA_Kirki::add_field( $config, array(
			'type'     => 'typography',
			'settings' => 'footer-content-typo',
			'label'    => esc_html__( 'Content Typography', 'maaya' ),
			'section'  => 'dt_footer_typo',
			'output' => array(
				array( 'element' => 'div.footer-widgets .widget' )
			),
			'default' => maaya_defaults( 'footer-content-typo' ),
			'active_callback' => array(
				array( 'setting' => 'customize-footer-content-typo', 'operator' => '==', 'value' => '1' )
			)		
		));

		# footer-content-a-color		
		MAAYA_Kirki::add_field( $config, array(
			'type'     => 'color',
			'settings' => 'footer-content-a-color',
			'label'    => esc_html__( 'Anchor Color', 'maaya' ),
			'section'  => 'dt_footer_typo',
			'choices' => array( 'alpha' => true ),
			'output' => array(
				array( 'element' => '.footer-widgets a, #footer a' )
			),
			'default' => maaya_defaults( 'footer-content-a-color' ),
			'active_callback' => array(
				array( 'setting' => 'customize-footer-content-typo', 'operator' => '==', 'value' => '1' )
			)		
		));

		# footer-content-a-hover-color
		MAAYA_Kirki::add_field( $config, array(
			'type'     => 'color',
			'settings' => 'footer-content-a-hover-color',
			'label'    => esc_html__( 'Anchor Hover Color', 'maaya' ),
			'section'  => 'dt_footer_typo',
			'choices' => array( 'alpha' => true ),			
			'output' => array(
				array( 'element' => '.footer-widgets a:hover, #footer a:hover' )
			),
			'default' => maaya_defaults( 'footer-content-a-hover-color' ),
			'active_callback' => array(
				array( 'setting' => 'customize-footer-content-typo', 'operator' => '==', 'value' => '1' )
			)		
		));