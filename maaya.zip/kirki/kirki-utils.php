<?php
function maaya_kirki_config() {
	return 'maaya_kirki_config';
}

function maaya_defaults( $key = '' ) {
	$defaults = array();

	# site identify
	$defaults['use-custom-logo'] = '1';
	$defaults['custom-logo'] = MAAYA_THEME_URI.'/images/logo.png';
	$defaults['custom-light-logo'] = MAAYA_THEME_URI.'/images/light-logo.png';
	$defaults['site_icon'] = MAAYA_THEME_URI.'/images/favicon.ico';

	# site layout
	$defaults['site-layout'] = 'wide';
	$defaults['body-bg-color']      = '#ffffff';
	$defaults['body-content-color'] = '#707070';
	$defaults['body-a-color']       = '#627a59';
	$defaults['body-a-hover-color'] = '#000000';
	$defaults['custom-title'] = '#ffffff';
	

	# site skin
	$defaults['primary-color'] = '#627a59';
	$defaults['secondary-color'] = '#384f30';
	$defaults['tertiary-color'] = '#acbfa5';

	$defaults['enable-custom-fonts'] = '1';
	$defaults['custom-font-name'] = 'Truenorg';
	$defaults['custom-font-woff'] = MAAYA_THEME_URI.'/fonts/truenorg-webfont.woff';
	$defaults['custom-font-woff2'] = MAAYA_THEME_URI.'/fonts/truenorg-webfont.woff2';
	


	# site breadcrumb

	$defaults['custom-breadcrumb-color'] = '#000000';

	$defaults['customize-breadcrumb-title-typo'] = '0';
	$defaults['breadcrumb-title-typo'] = array( 'font-family' => 'Montserrat',
		'variant' => 'regular',
		'subsets' => array( 'latin-ext' ),
		'font-size' => '20px',
		'line-height' => '',
		'letter-spacing' => '0.5px',
		'color' => '#000000',
		'text-align' => 'unset',
		'text-transform' => 'none' );
	$defaults['customize-breadcrumb-typo'] = '0';
	$defaults['breadcrumb-typo'] = array( 'font-family' => 'Montserrat',
		'variant' => 'regular',
		'subsets' => array( 'latin-ext' ),
		'font-size' => '20px',
		'line-height' => '',
		'letter-spacing' => '0',
		'color' => '#333333',
		'text-align' => 'unset',
		'text-transform' => 'none' );

	# site footer
	$defaults['customize-footer-title-typo'] = '0';
	$defaults['footer-title-typo'] = array( 'font-family' => 'Montserrat',
		'variant' => '700',
		'subsets' => array( 'latin-ext' ),
		'font-size' => '20px',
		'line-height' => '36px',
		'letter-spacing' => '0',
		'color' => '#2b2b2b',
		'text-align' => 'left',
		'text-transform' => 'none' );
	$defaults['customize-footer-content-typo'] = '1';
	$defaults['footer-content-typo'] = array( 'font-family' => 'Noto Sans',
		'variant' => 'regular',
		'subsets' => array( 'latin-ext' ),
		'font-size' => '13px',
		'line-height' => '24px',
		'letter-spacing' => '1px',
		'color' => '#d7d7d7',
		'text-align' => 'left',
		'text-transform' => 'none' );

	# site typography
	$defaults['customize-body-h1-typo'] = '0';
	$defaults['h1'] = array(
		'font-family' => 'Montserrat',
		'variant' => '300',
		'font-size' => '41px',
		'line-height' => '',
		'letter-spacing' => '0.5px',
		'color' => '#000000',
		'text-align' => 'unset',
		'text-transform' => 'none'
	);
	$defaults['customize-body-h2-typo'] = '0';
	$defaults['h2'] = array(
		'font-family' => 'Montserrat',
		'variant' => '300',
		'font-size' => '32px',
		'line-height' => '',
		'letter-spacing' => '0.5px',
		'color' => '#000000',
		'text-align' => 'unset',
		'text-transform' => 'none'
	);
	$defaults['customize-body-h3-typo'] = '0';
	$defaults['h3'] = array(
		'font-family' => 'Montserrat',
		'variant' => '300',
		'font-size' => '28px',
		'line-height' => '',
		'letter-spacing' => '0.5px',
		'color' => '#000000',
		'text-align' => 'unset',
		'text-transform' => 'none'
	);
	$defaults['customize-body-h4-typo'] = '0';
	$defaults['h4'] = array(
		'font-family' => 'Montserrat',
		'variant' => '300',
		'font-size' => '24px',
		'line-height' => '',
		'letter-spacing' => '0.5px',
		'color' => '#000000',
		'text-align' => 'unset',
		'text-transform' => 'none'
	);
	$defaults['customize-body-h5-typo'] = '0';
	$defaults['h5'] = array(
		'font-family' => 'Montserrat',
		'variant' => '300',
		'font-size' => '20px',
		'line-height' => '',
		'letter-spacing' => '0.5px',
		'color' => '#000000',
		'text-align' => 'unset',
		'text-transform' => 'none'
	);
	$defaults['customize-body-h6-typo'] = '0';
	$defaults['h6'] = array(
		'font-family' => 'Montserrat',
		'variant' => '300',
		'font-size' => '16px',
		'line-height' => '',
		'letter-spacing' => '0.5px',
		'color' => '#000000',
		'text-align' => 'unset',
		'text-transform' => 'none'
	);
	$defaults['customize-body-content-typo'] = '1';
	$defaults['body-content-typo'] = array(
		'font-family' => 'Noto Sans',
		'variant' => 'normal',
		'font-size' => '13px',
		'line-height' => '24px',
		'letter-spacing' => '',
		'color' => '#707070',
		'text-align' => 'inherit',
		'text-transform' => 'none'
	);
	
	$defaults['custom-h1-font-size'] = '41';
	$defaults['custom-h1-font-weight'] = '400';
	$defaults['custom-h1-letter-spacing'] = '0.5px';
	$defaults['custom-h1-color'] = '#000000';

	$defaults['custom-h2-font-size'] = '32';
	$defaults['custom-h2-font-weight'] = '300';
	$defaults['custom-h2-letter-spacing'] = '0.5px';
	$defaults['custom-h2-color'] = '#000000';

	$defaults['custom-h3-font-size'] = '28';
	$defaults['custom-h3-font-weight'] = '300';
	$defaults['custom-h3-letter-spacing'] = '0.5px';
	$defaults['custom-h3-color'] = '#000000';

	$defaults['custom-h4-font-size'] = '24';
	$defaults['custom-h4-font-weight'] = '300';
	$defaults['custom-h4-letter-spacing'] = '0.5px';
	$defaults['custom-h4-color'] = '#000000';

	$defaults['custom-h5-font-size'] = '20';
	$defaults['custom-h5-font-weight'] = '300';
	$defaults['custom-h5-letter-spacing'] = '0.5px';
	$defaults['custom-h5-color'] = '#000000';

	$defaults['custom-h6-font-size'] = '16';
	$defaults['custom-h6-font-weight'] = '300';
	$defaults['custom-h6-letter-spacing'] = '0.5px';
	$defaults['custom-h6-color'] = '#000000';

	$defaults['custom-body-font-size'] = '13';
	$defaults['custom-body-font-weight'] = 'normal';
	$defaults['custom-body-letter-spacing'] = '0px';
	$defaults['custom-body-color'] = '#707070';	

	$defaults['footer-content-a-color'] = '#ffffff';
	$defaults['footer-content-a-hover-color'] = '#d7d7d7';
	$defaults['custom-footer-title-color'] = '#2b2b2b';
	$defaults['custom-footer-title-font-weight'] = '700';
	$defaults['custom-breadcrumb-title-font-size'] = '20';
	$defaults['custom-footer-title-font-size'] = '20';

	if( !empty( $key ) && array_key_exists( $key, $defaults) ) {
		return $defaults[$key];
	}

	return '';
}

function maaya_image_positions() {

	$positions = array( "top left" => esc_attr__('Top Left','maaya'),
		"top center"    => esc_attr__('Top Center','maaya'),
		"top right"     => esc_attr__('Top Right','maaya'),
		"center left"   => esc_attr__('Center Left','maaya'),
		"center center" => esc_attr__('Center Center','maaya'),
		"center right"  => esc_attr__('Center Right','maaya'),
		"bottom left"   => esc_attr__('Bottom Left','maaya'),
		"bottom center" => esc_attr__('Bottom Center','maaya'),
		"bottom right"  => esc_attr__('Bottom Right','maaya'),
	);

	return $positions;
}

function maaya_image_repeats() {

	$image_repeats = array( "repeat" => esc_attr__('Repeat','maaya'),
		"repeat-x"  => esc_attr__('Repeat in X-axis','maaya'),
		"repeat-y"  => esc_attr__('Repeat in Y-axis','maaya'),
		"no-repeat" => esc_attr__('No Repeat','maaya')
	);

	return $image_repeats;
}

function maaya_border_styles() {

	$image_repeats = array(
		"none"	 => esc_attr__('None','maaya'),
		"dotted" => esc_attr__('Dotted','maaya'),
		"dashed" => esc_attr__('Dashed','maaya'),
		"solid"	 => esc_attr__('Solid','maaya'),
		"double" => esc_attr__('Double','maaya'),
		"groove" => esc_attr__('Groove','maaya'),
		"ridge"	 => esc_attr__('Ridge','maaya'),
	);

	return $image_repeats;
}

function maaya_animations() {

	$animations = array(
		'' 					 => esc_html__('Default','maaya'),	
		"bigEntrance"        =>  esc_attr__("bigEntrance",'maaya'),
        "bounce"             =>  esc_attr__("bounce",'maaya'),
        "bounceIn"           =>  esc_attr__("bounceIn",'maaya'),
        "bounceInDown"       =>  esc_attr__("bounceInDown",'maaya'),
        "bounceInLeft"       =>  esc_attr__("bounceInLeft",'maaya'),
        "bounceInRight"      =>  esc_attr__("bounceInRight",'maaya'),
        "bounceInUp"         =>  esc_attr__("bounceInUp",'maaya'),
        "bounceOut"          =>  esc_attr__("bounceOut",'maaya'),
        "bounceOutDown"      =>  esc_attr__("bounceOutDown",'maaya'),
        "bounceOutLeft"      =>  esc_attr__("bounceOutLeft",'maaya'),
        "bounceOutRight"     =>  esc_attr__("bounceOutRight",'maaya'),
        "bounceOutUp"        =>  esc_attr__("bounceOutUp",'maaya'),
        "expandOpen"         =>  esc_attr__("expandOpen",'maaya'),
        "expandUp"           =>  esc_attr__("expandUp",'maaya'),
        "fadeIn"             =>  esc_attr__("fadeIn",'maaya'),
        "fadeInDown"         =>  esc_attr__("fadeInDown",'maaya'),
        "fadeInDownBig"      =>  esc_attr__("fadeInDownBig",'maaya'),
        "fadeInLeft"         =>  esc_attr__("fadeInLeft",'maaya'),
        "fadeInLeftBig"      =>  esc_attr__("fadeInLeftBig",'maaya'),
        "fadeInRight"        =>  esc_attr__("fadeInRight",'maaya'),
        "fadeInRightBig"     =>  esc_attr__("fadeInRightBig",'maaya'),
        "fadeInUp"           =>  esc_attr__("fadeInUp",'maaya'),
        "fadeInUpBig"        =>  esc_attr__("fadeInUpBig",'maaya'),
        "fadeOut"            =>  esc_attr__("fadeOut",'maaya'),
        "fadeOutDownBig"     =>  esc_attr__("fadeOutDownBig",'maaya'),
        "fadeOutLeft"        =>  esc_attr__("fadeOutLeft",'maaya'),
        "fadeOutLeftBig"     =>  esc_attr__("fadeOutLeftBig",'maaya'),
        "fadeOutRight"       =>  esc_attr__("fadeOutRight",'maaya'),
        "fadeOutUp"          =>  esc_attr__("fadeOutUp",'maaya'),
        "fadeOutUpBig"       =>  esc_attr__("fadeOutUpBig",'maaya'),
        "flash"              =>  esc_attr__("flash",'maaya'),
        "flip"               =>  esc_attr__("flip",'maaya'),
        "flipInX"            =>  esc_attr__("flipInX",'maaya'),
        "flipInY"            =>  esc_attr__("flipInY",'maaya'),
        "flipOutX"           =>  esc_attr__("flipOutX",'maaya'),
        "flipOutY"           =>  esc_attr__("flipOutY",'maaya'),
        "floating"           =>  esc_attr__("floating",'maaya'),
        "hatch"              =>  esc_attr__("hatch",'maaya'),
        "hinge"              =>  esc_attr__("hinge",'maaya'),
        "lightSpeedIn"       =>  esc_attr__("lightSpeedIn",'maaya'),
        "lightSpeedOut"      =>  esc_attr__("lightSpeedOut",'maaya'),
        "pullDown"           =>  esc_attr__("pullDown",'maaya'),
        "pullUp"             =>  esc_attr__("pullUp",'maaya'),
        "pulse"              =>  esc_attr__("pulse",'maaya'),
        "rollIn"             =>  esc_attr__("rollIn",'maaya'),
        "rollOut"            =>  esc_attr__("rollOut",'maaya'),
        "rotateIn"           =>  esc_attr__("rotateIn",'maaya'),
        "rotateInDownLeft"   =>  esc_attr__("rotateInDownLeft",'maaya'),
        "rotateInDownRight"  =>  esc_attr__("rotateInDownRight",'maaya'),
        "rotateInUpLeft"     =>  esc_attr__("rotateInUpLeft",'maaya'),
        "rotateInUpRight"    =>  esc_attr__("rotateInUpRight",'maaya'),
        "rotateOut"          =>  esc_attr__("rotateOut",'maaya'),
        "rotateOutDownRight" =>  esc_attr__("rotateOutDownRight",'maaya'),
        "rotateOutUpLeft"    =>  esc_attr__("rotateOutUpLeft",'maaya'),
        "rotateOutUpRight"   =>  esc_attr__("rotateOutUpRight",'maaya'),
        "shake"              =>  esc_attr__("shake",'maaya'),
        "slideDown"          =>  esc_attr__("slideDown",'maaya'),
        "slideExpandUp"      =>  esc_attr__("slideExpandUp",'maaya'),
        "slideLeft"          =>  esc_attr__("slideLeft",'maaya'),
        "slideRight"         =>  esc_attr__("slideRight",'maaya'),
        "slideUp"            =>  esc_attr__("slideUp",'maaya'),
        "stretchLeft"        =>  esc_attr__("stretchLeft",'maaya'),
        "stretchRight"       =>  esc_attr__("stretchRight",'maaya'),
        "swing"              =>  esc_attr__("swing",'maaya'),
        "tada"               =>  esc_attr__("tada",'maaya'),
        "tossing"            =>  esc_attr__("tossing",'maaya'),
        "wobble"             =>  esc_attr__("wobble",'maaya'),
        "fadeOutDown"        =>  esc_attr__("fadeOutDown",'maaya'),
        "fadeOutRightBig"    =>  esc_attr__("fadeOutRightBig",'maaya'),
        "rotateOutDownLeft"  =>  esc_attr__("rotateOutDownLeft",'maaya')
    );

	return $animations;
}

function maaya_font_weights() {

	$font_weights = array(
		'normal' => esc_attr__('Normal', 'maaya'),
		'100'	 => '100',
		'200'	 => '200',
		'300' 	 => '300',
		'400' 	 => '400',
		'500'  	 => '500',
		'600'	 => '600',
		'700'	 => '700',
		'800'	 => '800',
		'900'	 => '900',
		'bold'	 => esc_attr__('Bold', 'maaya'),
		'bolder' => esc_attr__('Bolder', 'maaya'),
		'lighter' => esc_attr__('Lighter', 'maaya'),
		'inherit' => esc_attr__('Inherit', 'maaya')
	);

	return $font_weights;
}

function maaya_letter_spacing() {

	$letter_spacing = array('-3px' => '-3px', '-2px' => '-2px', '-1px' => '-1px', '-0.75px' => '-0.75px', '-0.5px' => '-0.5px', '-0.25px' => '-0.25px', '-0.1px' => '-0.1px', '-0.05px' => '-0.05px', '0px' => '0px', '0.05px' => '0.05px', '0.1px' => '0.1px', '0.25px' => '0.25px', '0.5px' => '0.5px', '0.75px' => '0.75px', '1px' => '1px', '2px' => '2px', '3px' => '3px');

	return $letter_spacing;
}