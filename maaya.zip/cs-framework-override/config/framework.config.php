<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// FRAMEWORK SETTINGS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$settings           = array(
  'menu_title'      => constant('MAAYA_THEME_NAME').' '.esc_html__('Options', 'maaya'),
  'menu_type'       => 'theme', // menu, submenu, options, theme, etc.
  'menu_slug'       => 'cs-framework',
  'ajax_save'       => true,
  'show_reset_all'  => false,
  'framework_title' => sprintf(esc_html__('Designthemes Framework %sby Designthemes%s', 'maaya'),'<small>','</small>')
);

// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// FRAMEWORK OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options        = array();

$options[]      = array(
  'name'        => 'general',
  'title'       => esc_html__('General', 'maaya'),
  'icon'        => 'fa fa-gears',

  'fields'      => array(

	array(
	  'type'    => 'subheading',
	  'content' => esc_html__( 'General Options', 'maaya' ),
	),
	
	array(
		'id'	=> 'header',
		'type'	=> 'select',
		'title'	=> esc_html__('Site Header', 'maaya'),
		'class'	=> 'chosen',
		'options'	=> 'posts',
		'query_args'	=> array(
			'post_type'	=> 'dt_headers',
			'orderby'	=> 'title',
			'order'	=> 'ASC',
			'posts_per_page' => -1
		),
		'default_option'	=> esc_attr__('Select Header', 'maaya'),
		'attributes'	=> array ( 'style'	=> 'width:50%'),
		'info'	=> esc_html__('Select default header.','maaya'),
	),
	
	array(
		'id'	=> 'footer',
		'type'	=> 'select',
		'title'	=> esc_html__('Site Footer', 'maaya'),
		'class'	=> 'chosen',
		'options'	=> 'posts',
		'query_args'	=> array(
			'post_type'	=> 'dt_footers',
			'orderby'	=> 'title',
			'order'	=> 'ASC',
			'posts_per_page' => -1
		),
		'default_option'	=> esc_attr__('Select Footer', 'maaya'),
		'attributes'	=> array ( 'style'	=> 'width:50%'),
		'info'	=> esc_html__('Select defaultfooter.','maaya'),
	),

	array(
	  'id'  	 => 'use-site-loader',
	  'type'  	 => 'switcher',
	  'title' 	 => esc_html__('Site Loader', 'maaya'),
	  'info'	 => esc_html__('YES! to use site loader.', 'maaya'),
	  'default'  => true
	),	

	array(
	  'id'  	 => 'enable-stylepicker',
	  'type'  	 => 'switcher',
	  'title' 	 => esc_html__('Style Picker', 'maaya'),
	  'info'	 => esc_html__('YES! to show the style picker.', 'maaya')
	),		

	array(
	  'id'  	 => 'show-pagecomments',
	  'type'  	 => 'switcher',
	  'title' 	 => esc_html__('Globally Show Page Comments', 'maaya'),
	  'info'	 => esc_html__('YES! to show comments on all the pages. This will globally override your "Allow comments" option under your page "Discussion" settings.', 'maaya'),
	  'default'  => true,
	),

	array(
	  'id'  	 => 'showall-pagination',
	  'type'  	 => 'switcher',
	  'title' 	 => esc_html__('Show all pages in Pagination', 'maaya'),
	  'info'	 => esc_html__('YES! to show all the pages instead of dots near the current page.', 'maaya')
	),



	array(
	  'id'      => 'google-map-key',
	  'type'    => 'text',
	  'title'   => esc_html__('Google Map API Key', 'maaya'),
	  'after' 	=> '<p class="cs-text-info">'.esc_html__('Put a valid google account api key here', 'maaya').'</p>',
	),

	array(
	  'id'      => 'mailchimp-key',
	  'type'    => 'text',
	  'title'   => esc_html__('Mailchimp API Key', 'maaya'),
	  'after' 	=> '<p class="cs-text-info">'.esc_html__('Put a valid mailchimp account api key here', 'maaya').'</p>',
	  'default' => 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'
	),

  ),
);

$options[]      = array(
  'name'        => 'layout_options',
  'title'       => esc_html__('Layout Options', 'maaya'),
  'icon'        => 'dashicons dashicons-exerpt-view',
  'sections' => array(

	// -----------------------------------------
	// Header Options
	// -----------------------------------------
	array(
	  'name'      => 'breadcrumb_options',
	  'title'     => esc_html__('Breadcrumb Options', 'maaya'),
	  'icon'      => 'fa fa-sitemap',

		'fields'      => array(

		  array(
			'type'    => 'subheading',
			'content' => esc_html__( "Breadcrumb Options", 'maaya' ),
		  ),

		  array(
			'id'  		 => 'show-breadcrumb',
			'type'  	 => 'switcher',
			'title' 	 => esc_html__('Show Breadcrumb', 'maaya'),
			'info'		 => esc_html__('YES! to display breadcrumb for all pages.', 'maaya'),
			'default' 	 => false,
		  ),

		  array(
			'id'           => 'breadcrumb-delimiter',
			'type'         => 'icon',
			'title'        => esc_html__('Breadcrumb Delimiter', 'maaya'),
			'info'         => esc_html__('Choose delimiter style to display on breadcrumb section.', 'maaya'),
		  ),

		  array(
			'id'           => 'breadcrumb-style',
			'type'         => 'select',
			'title'        => esc_html__('Breadcrumb Style', 'maaya'),
			'options'      => array(
			  'default' 							=> esc_html__('Default', 'maaya'),
			  'aligncenter'    						=> esc_html__('Align Center', 'maaya'),
			  'alignright'  						=> esc_html__('Align Right', 'maaya'),
			  'breadcrumb-left'    					=> esc_html__('Left Side Breadcrumb', 'maaya'),
			  'breadcrumb-right'     				=> esc_html__('Right Side Breadcrumb', 'maaya'),
			  'breadcrumb-top-right-title-center'  	=> esc_html__('Top Right Title Center', 'maaya'),
			  'breadcrumb-top-left-title-center'  	=> esc_html__('Top Left Title Center', 'maaya'),
			),
			'class'        => 'chosen',
			'default'      => 'aligncenter',
			'info'         => esc_html__('Choose alignment style to display on breadcrumb section.', 'maaya'),
		  ),

		  array(
			  'id'                 => 'breadcrumb-position',
			  'type'               => 'select',
			  'title'              => esc_html__('Position', 'maaya' ),
			  'options'            => array(
				  'header-top-absolute'    => esc_html__('Behind the Header','maaya'),
				  'header-top-relative'    => esc_html__('Default','maaya'),
			  ),
			  'class'        => 'chosen',
			  'default'      => 'header-top-relative',
			  'info'         => esc_html__('Choose position of breadcrumb section.', 'maaya'),
		  ),

		  array(
			'id'    => 'breadcrumb_background',
			'type'  => 'background',
			'title' => esc_html__('Background', 'maaya'),
			'desc'  => esc_html__('Choose background options for breadcrumb title section.', 'maaya')
		  ),

		),
	),

  ),
);

$options[]      = array(
  'name'        => 'allpage_options',
  'title'       => esc_html__('All Page Options', 'maaya'),
  'icon'        => 'fa fa-files-o',
  'sections' => array(

	// -----------------------------------------
	// Post Options
	// -----------------------------------------
	array(
	  'name'      => 'post_options',
	  'title'     => esc_html__('Post Options', 'maaya'),
	  'icon'      => 'fa fa-file',

		'fields'      => array(

		  array(
			'type'    => 'subheading',
			'content' => esc_html__( "Single Post Options", 'maaya' ),
		  ),
		
		  array(
			'id'  		 => 'single-post-authorbox',
			'type'  	 => 'switcher',
			'title' 	 => esc_html__('Single Author Box', 'maaya'),
			'info'		 => esc_html__('YES! to display author box in single blog posts.', 'maaya'),
			'default'	 => true
		  ),

		  array(
			'id'  		 => 'single-post-related',
			'type'  	 => 'switcher',
			'title' 	 => esc_html__('Single Related Posts', 'maaya'),
			'info'		 => esc_html__('YES! to display related blog posts in single posts.', 'maaya'),
			'default'	 => true
		  ),

		  array(
			'id'  		 => 'single-post-navigation',
			'type'  	 => 'switcher',
			'title' 	 => esc_html__('Single Post Navigation', 'maaya'),
			'info'		 => esc_html__('YES! to display post navigation in single posts.', 'maaya'),
			'default'	 => true
		  ),

		  array(
			'id'  		 => 'single-post-comments',
			'type'  	 => 'switcher',
			'title' 	 => esc_html__('Posts Comments', 'maaya'),
			'info'		 => esc_html__('YES! to display single blog post comments.', 'maaya'),
			'default' 	 => true,
		  ),

		  array(
			'type'    => 'subheading',
			'content' => esc_html__( "Post Archives Page Layout", 'maaya' ),
		  ),

		  array(
			'id'      	 => 'post-archives-page-layout',
			'type'       => 'image_select',
			'title'      => esc_html__('Page Layout', 'maaya'),
			'options'    => array(
			  'content-full-width'   => MAAYA_THEME_URI . '/cs-framework-override/images/without-sidebar.png',
			  'with-left-sidebar'    => MAAYA_THEME_URI . '/cs-framework-override/images/left-sidebar.png',
			  'with-right-sidebar'   => MAAYA_THEME_URI . '/cs-framework-override/images/right-sidebar.png',
			  'with-both-sidebar'    => MAAYA_THEME_URI . '/cs-framework-override/images/both-sidebar.png',
			),
			'default'      => 'with-right-sidebar',
			'attributes'   => array(
			  'data-depend-id' => 'post-archives-page-layout',
			),
		  ),

		  array(
			'id'  		 => 'show-standard-left-sidebar-for-post-archives',
			'type'  	 => 'switcher',
			'title' 	 => esc_html__('Show Standard Left Sidebar', 'maaya'),
			'dependency' => array( 'post-archives-page-layout', 'any', 'with-left-sidebar,with-both-sidebar' ),
		  ),

		  array(
			'id'  		 => 'show-standard-right-sidebar-for-post-archives',
			'type'  	 => 'switcher',
			'title' 	 => esc_html__('Show Standard Right Sidebar', 'maaya'),
			'dependency' => array( 'post-archives-page-layout', 'any', 'with-right-sidebar,with-both-sidebar' ),
			'default' => true
		  ),

		  array(
			'type'    => 'subheading',
			'content' => esc_html__( "Post Archives Post Layout", 'maaya' ),
		  ),

		  array(
			'id'      	   => 'post-archives-post-layout',
			'type'         => 'image_select',
			'title'        => esc_html__('Post Layout', 'maaya'),
			'options'      => array(
			  'one-column' 		  => MAAYA_THEME_URI . '/cs-framework-override/images/one-column.png',
			  'one-half-column'   => MAAYA_THEME_URI . '/cs-framework-override/images/one-half-column.png',
			  'one-third-column'  => MAAYA_THEME_URI . '/cs-framework-override/images/one-third-column.png',
			  '1-2-2'			  => MAAYA_THEME_URI . '/cs-framework-override/images/1-2-2.png',
			  '1-2-2-1-2-2' 	  => MAAYA_THEME_URI . '/cs-framework-override/images/1-2-2-1-2-2.png',
			  '1-3-3-3'			  => MAAYA_THEME_URI . '/cs-framework-override/images/1-3-3-3.png',
			  '1-3-3-3-1' 		  => MAAYA_THEME_URI . '/cs-framework-override/images/1-3-3-3-1.png',
			),
			'default'      => 'one-third-column',
		  ),

		  array(
			'id'           => 'post-style',
			'type'         => 'select',
			'title'        => esc_html__('Post Style', 'maaya'),
			'options'      => array(
			  'blog-default-style' 		=> esc_html__('Default', 'maaya'),
			  'entry-date-left'      	=> esc_html__('Date Left', 'maaya'),
			  'entry-date-left outer-frame-border'      	=> esc_html__('Date Left Modern', 'maaya'),
			  'entry-date-author-left'  => esc_html__('Date and Author Left', 'maaya'),
			  'blog-modern-style'       => esc_html__('Modern', 'maaya'),
			  'bordered'      			=> esc_html__('Bordered', 'maaya'),
			  'classic'      			=> esc_html__('Classic', 'maaya'),
			  'entry-overlay-style' 	=> esc_html__('Trendy', 'maaya'),
			  'overlap' 				=> esc_html__('Overlap', 'maaya'),
			  'entry-center-align'		=> esc_html__('Stripe', 'maaya'),
			  'entry-fashion-style'	 	=> esc_html__('Fashion', 'maaya'),
			  'entry-minimal-bordered' 	=> esc_html__('Minimal Bordered', 'maaya'),
			  'blog-medium-style'       => esc_html__('Medium', 'maaya'),
			  'blog-medium-style dt-blog-medium-highlight'     					 => esc_html__('Medium Hightlight', 'maaya'),
			  'blog-medium-style dt-blog-medium-highlight dt-sc-skin-highlight'  => esc_html__('Medium Skin Highlight', 'maaya'),
			  'entry-flat'  => esc_html__('Flat', 'maaya'),
			),
			'class'        => 'chosen',
			'default'      => 'entry-flat',
			'info'         => esc_html__('Choose post style to display post archives pages.', 'maaya'),
		  ),

		  array(
			'id'  		 => 'post-archives-enable-excerpt',
			'type'  	 => 'switcher',
			'title' 	 => esc_html__('Allow Excerpt', 'maaya'),
			'info'		 => esc_html__('YES! to allow excerpt', 'maaya'),
			'default'    => true,
		  ),

		  array(
			'id'  		 => 'post-archives-excerpt',
			'type'  	 => 'number',
			'title' 	 => esc_html__('Excerpt Length', 'maaya'),
			'after'		 => '<span class="cs-text-desc">&nbsp;'.esc_html__('Put Excerpt Length', 'maaya').'</span>',
			'default' 	 => 34,
		  ),

		  array(
			'id'  		 => 'post-archives-enable-readmore',
			'type'  	 => 'switcher',
			'title' 	 => esc_html__('Read More', 'maaya'),
			'info'		 => esc_html__('YES! to enable read more button', 'maaya'),
			'default'	 => true,
		  ),

		  array(
			'id'  		 => 'post-archives-readmore',
			'type'  	 => 'textarea',
			'title' 	 => esc_html__('Read More Shortcode', 'maaya'),
			'info'		 => esc_html__('Paste any button shortcode here', 'maaya'),
			'default'	 => '[dt_sc_button title="Read More" style="bordered" size="small"]',
			'dependency' => array( 'post-style', 'any', 'blog-default-style,entry-date-left,entry-date-left outer-frame-border,entry-date-author-left,blog-modern-style,bordered,classic,entry-overlay-style,overlap,entry-center-align,entry-fashion-style,entry-minimal-bordered,blog-medium-style,blog-medium-style dt-blog-medium-highlight,blog-medium-style dt-blog-medium-highlight dt-sc-skin-highlight' )
		  ),

		  array(
			'id'         => 'post-archives-readmore-text',
			'type'       => 'text',
			'title'      => esc_html__('Read More Text', 'maaya' ),
			'default'    => esc_html__('Read More', 'maaya' ),
			'dependency' => array( 'post-style', 'any', 'entry-flat,entry-flat type2,entry-alternate,entry-flat list' )
		  ),

		  array(
			'type'    => 'subheading',
			'content' => esc_html__( "Single Post & Post Archive options", 'maaya' ),
		  ),

		  array(
			'id'      => 'post-format-meta',
			'type'    => 'switcher',
			'title'   => esc_html__('Post Format Meta', 'maaya' ),
			'info'	  => esc_html__('YES! to show post format meta information', 'maaya'),
			'default' => false
		  ),

		  array(
			'id'      => 'post-author-meta',
			'type'    => 'switcher',
			'title'   => esc_html__('Author Meta', 'maaya' ),
			'info'	  => esc_html__('YES! to show post author meta information', 'maaya'),
			'default' => false
		  ),

		  array(
			'id'      => 'post-date-meta',
			'type'    => 'switcher',
			'title'   => esc_html__('Date Meta', 'maaya' ),
			'info'	  => esc_html__('YES! to show post date meta information', 'maaya'),
		  ),

		  array(
			'id'      => 'post-comment-meta',
			'type'    => 'switcher',
			'title'   => esc_html__('Comment Meta', 'maaya' ),
			'info'	  => esc_html__('YES! to show post comment meta information', 'maaya'),
		  ),

		  array(
			'id'      => 'post-category-meta',
			'type'    => 'switcher',
			'title'   => esc_html__('Category Meta', 'maaya' ),
			'info'	  => esc_html__('YES! to show post category information', 'maaya'),
			'default' => true
		  ),

		  array(
			'id'      => 'post-tag-meta',
			'type'    => 'switcher',
			'title'   => esc_html__('Tag Meta', 'maaya' ),
			'info'	  => esc_html__('YES! to show post tag information', 'maaya'),
			),
			
			array(
				'id'      => 'post-likes',
				'type'    => 'switcher',
				'title'   => esc_html__('Post Likes', 'maaya' ),
				'info'    => esc_html__('YES! to show post likes information', 'maaya'),
			),

			array(
				'id'      => 'post-views',
				'type'    => 'switcher',
				'title'   => esc_html__('Post Views', 'maaya' ),
				'info'    => esc_html__('YES! to show post views information', 'maaya'),
			),

		),
	),

	// -----------------------------------------
	// 404 Options
	// -----------------------------------------
	array(
	  'name'      => '404_options',
	  'title'     => esc_html__('404 Options', 'maaya'),
	  'icon'      => 'fa fa-warning',

		'fields'      => array(

		  array(
			'type'    => 'subheading',
			'content' => esc_html__( "404 Message", 'maaya' ),
		  ),
		  
		  array(
			'id'      => 'enable-404message',
			'type'    => 'switcher',
			'title'   => esc_html__('Enable Message', 'maaya' ),
			'info'	  => esc_html__('YES! to enable not-found page message.', 'maaya'),
			'default' => true
		  ),

		  array(
			'id'           => 'notfound-style',
			'type'         => 'select',
			'title'        => esc_html__('Template Style', 'maaya'),
			'options'      => array(
			  'type1' 	   => esc_html__('Modern', 'maaya'),
			  'type2'      => esc_html__('Classic', 'maaya'),
			  'type4'  	   => esc_html__('Diamond', 'maaya'),
			  'type5'      => esc_html__('Shadow', 'maaya'),
			  'type6'      => esc_html__('Diamond Alt', 'maaya'),
			  'type7'  	   => esc_html__('Stack', 'maaya'),
			  'type8'  	   => esc_html__('Minimal', 'maaya'),
			),
			'class'        => 'chosen',
			'default'      => 'type7',
			'info'         => esc_html__('Choose the style of not-found template page.', 'maaya')
		  ),

		  array(
			'id'      => 'notfound-darkbg',
			'type'    => 'switcher',
			'title'   => esc_html__('404 Dark BG', 'maaya' ),
			'info'	  => esc_html__('YES! to use dark bg notfound page for this site.', 'maaya'),
			'default' => true
		  ),

		  array(
			'id'           => 'notfound-pageid',
			'type'         => 'select',
			'title'        => esc_html__('Custom Page', 'maaya'),
			'options'      => 'pages',
			'class'        => 'chosen',
			'default_option' => esc_html__('Choose the page', 'maaya'),
			'info'       	 => esc_html__('Choose the page for not-found content.', 'maaya')
		  ),
		  
		  array(
			'type'    => 'subheading',
			'content' => esc_html__( "Background Options", 'maaya' ),
		  ),

		  array(
			'id'    => 'notfound_background',
			'type'  => 'background',
			'title' => esc_html__('Background', 'maaya'),
			'default' => array(
              'image' => MAAYA_THEME_URI . '/images/404-image.jpg'                 
            ),
		  ),

		  array(
			'id'  		 => 'notfound-bg-style',
			'type'  	 => 'textarea',
			'title' 	 => esc_html__('Custom Styles', 'maaya'),
			'info'		 => esc_html__('Paste custom CSS styles for not found page.', 'maaya')
		  ),

		),
	),

	// -----------------------------------------
	// Underconstruction Options
	// -----------------------------------------
	array(
	  'name'      => 'comingsoon_options',
	  'title'     => esc_html__('Under Construction Options', 'maaya'),
	  'icon'      => 'fa fa-thumbs-down',

		'fields'      => array(

		  array(
			'type'    => 'subheading',
			'content' => esc_html__( "Under Construction", 'maaya' ),
		  ),
	
		  array(
			'id'      => 'enable-comingsoon',
			'type'    => 'switcher',
			'title'   => esc_html__('Enable Coming Soon', 'maaya' ),
			'info'	  => esc_html__('YES! to check under construction page of your website.', 'maaya')
		  ),
	
		  array(
			'id'           => 'comingsoon-style',
			'type'         => 'select',
			'title'        => esc_html__('Template Style', 'maaya'),
			'options'      => array(
			  'type1' 	   => esc_html__('Diamond', 'maaya'),
			  'type2'      => esc_html__('Teaser', 'maaya'),
			  'type3'  	   => esc_html__('Minimal', 'maaya'),
			  'type4'      => esc_html__('Counter Only', 'maaya'),
			  'type5'      => esc_html__('Belt', 'maaya'),
			  'type6'  	   => esc_html__('Classic', 'maaya'),
			  'type7'  	   => esc_html__('Boxed', 'maaya')
			),
			'class'        => 'chosen',
			'default'      => 'type1',
			'info'         => esc_html__('Choose the style of coming soon template.', 'maaya'),
		  ),

		  array(
			'id'      => 'uc-darkbg',
			'type'    => 'switcher',
			'title'   => esc_html__('Coming Soon Dark BG', 'maaya' ),
			'info'	  => esc_html__('YES! to use dark bg coming soon page for this site.', 'maaya')
		  ),

		  array(
			'id'           => 'comingsoon-pageid',
			'type'         => 'select',
			'title'        => esc_html__('Custom Page', 'maaya'),
			'options'      => 'pages',
			'class'        => 'chosen',
			'default_option' => esc_html__('Choose the page', 'maaya'),
			'info'       	 => esc_html__('Choose the page for comingsoon content.', 'maaya')
		  ),

		  array(
			'id'      => 'show-launchdate',
			'type'    => 'switcher',
			'title'   => esc_html__('Show Launch Date', 'maaya' ),
			'info'	  => esc_html__('YES! to show launch date text.', 'maaya'),
			'default' => true
		  ),

		  array(
			'id'      => 'comingsoon-launchdate',
			'type'    => 'text',
			'title'   => esc_html__('Launch Date', 'maaya'),
			'attributes' => array( 
			  'placeholder' => '10/30/2016 12:00:00'
			),
			'after' 	=> '<p class="cs-text-info">'.esc_html__('Put Format: 12/30/2016 12:00:00 month/day/year hour:minute:second', 'maaya').'</p>',
			'default' => '10/30/2018 12:00:00'
		  ),

		  array(
			'id'           => 'comingsoon-timezone',
			'type'         => 'select',
			'title'        => esc_html__('UTC Timezone', 'maaya'),
			'options'      => array(
			  '-12' => '-12', '-11' => '-11', '-10' => '-10', '-9' => '-9', '-8' => '-8', '-7' => '-7', '-6' => '-6', '-5' => '-5', 
			  '-4' => '-4', '-3' => '-3', '-2' => '-2', '-1' => '-1', '0' => '0', '+1' => '+1', '+2' => '+2', '+3' => '+3', '+4' => '+4',
			  '+5' => '+5', '+6' => '+6', '+7' => '+7', '+8' => '+8', '+9' => '+9', '+10' => '+10', '+11' => '+11', '+12' => '+12'
			),
			'class'        => 'chosen',
			'default'      => '+5',
			'info'         => esc_html__('Choose utc timezone, by default UTC:00:00', 'maaya'),
		  ),

		  array(
			'id'    => 'comingsoon_background',
			'type'  => 'background',
			'title' => esc_html__('Background', 'maaya'),
			'default' => array(
              'image' => MAAYA_THEME_URI . '/images/404-image.jpg'                 
            ),
		  ),

		  array(
			'id'  		 => 'comingsoon-bg-style',
			'type'  	 => 'textarea',
			'title' 	 => esc_html__('Custom Styles', 'maaya'),
			'info'		 => esc_html__('Paste custom CSS styles for under construction page.', 'maaya'),
		  ),

		),
	),

  ),
);

// -----------------------------------------
// Widget area Options
// -----------------------------------------
$options[]      = array(
  'name'        => 'widgetarea_options',
  'title'       => esc_html__('Widget Area', 'maaya'),
  'icon'        => 'fa fa-trello',

  'fields'      => array(

	  array(
		'type'    => 'subheading',
		'content' => esc_html__( "Custom Widget Area for Sidebar", 'maaya' ),
	  ),

	  array(
		'id'           => 'wtitle-style',
		'type'         => 'select',
		'title'        => esc_html__('Sidebar widget Title Style', 'maaya'),
		'options'      => array(
		  'default' => esc_html__('Choose any type', 'maaya'),
		  'type1' 	   => esc_html__('Double Border', 'maaya'),
		  'type2'      => esc_html__('Tooltip', 'maaya'),
		  'type3'  	   => esc_html__('Title Top Border', 'maaya'),
		  'type4'      => esc_html__('Left Border & Pattren', 'maaya'),
		  'type5'      => esc_html__('Bottom Border', 'maaya'),
		  'type6'  	   => esc_html__('Tooltip Border', 'maaya'),
		  'type7'  	   => esc_html__('Boxed Modern', 'maaya'),
		  'type8'  	   => esc_html__('Elegant Border', 'maaya'),
		  'type9' 	   => esc_html__('Needle', 'maaya'),
		  'type10' 	   => esc_html__('Ribbon', 'maaya'),
		  'type11' 	   => esc_html__('Content Background', 'maaya'),
		  'type12' 	   => esc_html__('Classic BG', 'maaya'),
		  'type13' 	   => esc_html__('Tiny Boders', 'maaya'),
		  'type14' 	   => esc_html__('BG & Border', 'maaya'),
		  'type15' 	   => esc_html__('Classic BG Alt', 'maaya'),
		  'type16' 	   => esc_html__('Left Border & BG', 'maaya'),
		  'type17' 	   => esc_html__('Basic', 'maaya'),
		  'type18' 	   => esc_html__('BG & Pattern', 'maaya'),
		),
		'class'          => 'chosen',
		'default' 		 =>  'default',
		'info'           => esc_html__('Choose the style of sidebar widget title.', 'maaya')
	  ),

	  array(
		'id'              => 'widgetarea-custom',
		'type'            => 'group',
		'title'           => esc_html__('Custom Widget Area', 'maaya'),
		'button_title'    => esc_html__('Add New', 'maaya'),
		'accordion_title' => esc_html__('Add New Widget Area', 'maaya'),
		'fields'          => array(

		  array(
			'id'          => 'widgetarea-custom-name',
			'type'        => 'text',
			'title'       => esc_html__('Name', 'maaya'),
		  ),

		)
	  ),

	),
);

// -----------------------------------------
// Woocommerce Options
// -----------------------------------------
if( function_exists( 'is_woocommerce' ) && ! class_exists ( 'DTWooPlugin' ) ){

	$options[]      = array(
	  'name'        => 'woocommerce_options',
	  'title'       => esc_html__('Woocommerce', 'maaya'),
	  'icon'        => 'fa fa-shopping-cart',

	  'fields'      => array(

		  array(
			'type'    => 'subheading',
			'content' => esc_html__( "Woocommerce Shop Page Options", 'maaya' ),
		  ),

		  array(
			'id'  		 => 'shop-product-per-page',
			'type'  	 => 'number',
			'title' 	 => esc_html__('Products Per Page', 'maaya'),
			'after'		 => '<span class="cs-text-desc">&nbsp;'.esc_html__('Number of products to show in catalog / shop page', 'maaya').'</span>',
			'default' 	 => 12,
		  ),

		  array(
			'id'           => 'product-style',
			'type'         => 'select',
			'title'        => esc_html__('Product Style', 'maaya'),
			'options'      => array(
			  'woo-type1' 	   => esc_html__('Thick Border', 'maaya'),
			  'woo-type4'      => esc_html__('Diamond Icons', 'maaya'),
			  'woo-type8' 	   => esc_html__('Modern', 'maaya'),
			  'woo-type10' 	   => esc_html__('Easing', 'maaya'),
			  'woo-type11' 	   => esc_html__('Boxed', 'maaya'),
			  'woo-type12' 	   => esc_html__('Easing Alt', 'maaya'),
			  'woo-type13' 	   => esc_html__('Parallel', 'maaya'),
			  'woo-type14' 	   => esc_html__('Pointer', 'maaya'),
			  'woo-type16' 	   => esc_html__('Stack', 'maaya'),
			  'woo-type17' 	   => esc_html__('Bouncy', 'maaya'),
			  'woo-type20' 	   => esc_html__('Masked Circle', 'maaya'),
			  'woo-type21' 	   => esc_html__('Classic', 'maaya')
			),
			'class'        => 'chosen',
			'default' 	   => 'woo-type1',
			'info'         => esc_html__('Choose products style to display shop & archive pages.', 'maaya')
		  ),

		  array(
			'id'      	 => 'shop-page-product-layout',
			'type'       => 'image_select',
			'title'      => esc_html__('Product Layout', 'maaya'),
			'options'    => array(
				  1   => MAAYA_THEME_URI . '/cs-framework-override/images/one-column.png',
				  2   => MAAYA_THEME_URI . '/cs-framework-override/images/one-half-column.png',
				  3   => MAAYA_THEME_URI . '/cs-framework-override/images/one-third-column.png',
				  4   => MAAYA_THEME_URI . '/cs-framework-override/images/one-fourth-column.png',
			),
			'default'      => 3,
			'attributes'   => array(
			  'data-depend-id' => 'shop-page-product-layout',
			),
		  ),

		  array(
			'type'    => 'subheading',
			'content' => esc_html__( "Product Detail Page Options", 'maaya' ),
		  ),

		  array(
			'id'      	   => 'product-layout',
			'type'         => 'image_select',
			'title'        => esc_html__('Layout', 'maaya'),
			'options'      => array(
			  'content-full-width'   => MAAYA_THEME_URI . '/cs-framework-override/images/without-sidebar.png',
			  'with-left-sidebar'    => MAAYA_THEME_URI . '/cs-framework-override/images/left-sidebar.png',
			  'with-right-sidebar'   => MAAYA_THEME_URI . '/cs-framework-override/images/right-sidebar.png',
			  'with-both-sidebar'    => MAAYA_THEME_URI . '/cs-framework-override/images/both-sidebar.png',
			),
			'default'      => 'content-full-width',
			'attributes'   => array(
			  'data-depend-id' => 'product-layout',
			),
		  ),

		  array(
			'id'  		 	 => 'show-shop-standard-left-sidebar-for-product-layout',
			'type'  		 => 'switcher',
			'title' 		 => esc_html__('Show Shop Standard Left Sidebar', 'maaya'),
			'dependency'   	 => array( 'product-layout', 'any', 'with-left-sidebar,with-both-sidebar' ),
		  ),

		  array(
			'id'  			 => 'show-shop-standard-right-sidebar-for-product-layout',
			'type'  		 => 'switcher',
			'title' 		 => esc_html__('Show Shop Standard Right Sidebar', 'maaya'),
			'dependency' 	 => array( 'product-layout', 'any', 'with-right-sidebar,with-both-sidebar' ),
		  ),

		  array(
			'id'  		 	 => 'enable-related',
			'type'  		 => 'switcher',
			'title' 		 => esc_html__('Show Related Products', 'maaya'),
			'info'	  		 => esc_html__("YES! to display related products on single product's page.", 'maaya'),
			'default'		 => true
		  ),

		  array(
			'type'    => 'subheading',
			'content' => esc_html__( "Product Category Page Options", 'maaya' ),
		  ),

		  array(
			'id'      	   => 'product-category-layout',
			'type'         => 'image_select',
			'title'        => esc_html__('Layout', 'maaya'),
			'options'      => array(
			  'content-full-width'   => MAAYA_THEME_URI . '/cs-framework-override/images/without-sidebar.png',
			  'with-left-sidebar'    => MAAYA_THEME_URI . '/cs-framework-override/images/left-sidebar.png',
			  'with-right-sidebar'   => MAAYA_THEME_URI . '/cs-framework-override/images/right-sidebar.png',
			  'with-both-sidebar'    => MAAYA_THEME_URI . '/cs-framework-override/images/both-sidebar.png',
			),
			'default'      => 'content-full-width',
			'attributes'   => array(
			  'data-depend-id' => 'product-category-layout',
			),
		  ),

		  array(
			'id'  		 	 => 'show-shop-standard-left-sidebar-for-product-category-layout',
			'type'  		 => 'switcher',
			'title' 		 => esc_html__('Show Shop Standard Left Sidebar', 'maaya'),
			'dependency'   	 => array( 'product-category-layout', 'any', 'with-left-sidebar,with-both-sidebar' ),
		  ),

		  array(
			'id'  			 => 'show-shop-standard-right-sidebar-for-product-category-layout',
			'type'  		 => 'switcher',
			'title' 		 => esc_html__('Show Shop Standard Right Sidebar', 'maaya'),
			'dependency' 	 => array( 'product-category-layout', 'any', 'with-right-sidebar,with-both-sidebar' ),
		  ),
		  
		  array(
			'type'    => 'subheading',
			'content' => esc_html__( "Product Tag Page Options", 'maaya' ),
		  ),

		  array(
			'id'      	   => 'product-tag-layout',
			'type'         => 'image_select',
			'title'        => esc_html__('Layout', 'maaya'),
			'options'      => array(
			  'content-full-width'   => MAAYA_THEME_URI . '/cs-framework-override/images/without-sidebar.png',
			  'with-left-sidebar'    => MAAYA_THEME_URI . '/cs-framework-override/images/left-sidebar.png',
			  'with-right-sidebar'   => MAAYA_THEME_URI . '/cs-framework-override/images/right-sidebar.png',
			  'with-both-sidebar'    => MAAYA_THEME_URI . '/cs-framework-override/images/both-sidebar.png',
			),
			'default'      => 'content-full-width',
			'attributes'   => array(
			  'data-depend-id' => 'product-tag-layout',
			),
		  ),

		  array(
			'id'  		 	 => 'show-shop-standard-left-sidebar-for-product-tag-layout',
			'type'  		 => 'switcher',
			'title' 		 => esc_html__('Show Shop Standard Left Sidebar', 'maaya'),
			'dependency'   	 => array( 'product-tag-layout', 'any', 'with-left-sidebar,with-both-sidebar' ),
		  ),

		  array(
			'id'  			 => 'show-shop-standard-right-sidebar-for-product-tag-layout',
			'type'  		 => 'switcher',
			'title' 		 => esc_html__('Show Shop Standard Right Sidebar', 'maaya'),
			'dependency' 	 => array( 'product-tag-layout', 'any', 'with-right-sidebar,with-both-sidebar' ),
		  ),

	  ),
	);
}

// -----------------------------------------
// Sociable Options
// -----------------------------------------
$options[]      = array(
  'name'        => 'sociable_options',
  'title'       => esc_html__('Sociable', 'maaya'),
  'icon'        => 'fa fa-share-alt-square',

  'fields'      => array(

	  array(
		'type'    => 'subheading',
		'content' => esc_html__( "Sociable", 'maaya' ),
	  ),

	  array(
		'id'              => 'sociable_fields',
		'type'            => 'group',
		'title'           => esc_html__('Sociable', 'maaya'),
		'info'            => esc_html__('Click button to add type of social & url.', 'maaya'),
		'button_title'    => esc_html__('Add New Social', 'maaya'),
		'accordion_title' => esc_html__('Adding New Social Field', 'maaya'),
		'fields'          => array(
		  array(
			'id'          => 'sociable_fields_type',
			'type'        => 'select',
			'title'       => esc_html__('Select Social', 'maaya'),
			'options'      => array(
			  'delicious' 	 => esc_html__('Delicious', 'maaya'),
			  'deviantart' 	 => esc_html__('Deviantart', 'maaya'),
			  'digg' 	  	 => esc_html__('Digg', 'maaya'),
			  'dribbble' 	 => esc_html__('Dribbble', 'maaya'),
			  'envelope' 	 => esc_html__('Envelope', 'maaya'),
			  'facebook' 	 => esc_html__('Facebook', 'maaya'),
			  'flickr' 		 => esc_html__('Flickr', 'maaya'),
			  'google-plus'  => esc_html__('Google Plus', 'maaya'),
			  'gtalk'  		 => esc_html__('GTalk', 'maaya'),
			  'instagram'	 => esc_html__('Instagram', 'maaya'),
			  'lastfm'	 	 => esc_html__('Lastfm', 'maaya'),
			  'linkedin'	 => esc_html__('Linkedin', 'maaya'),
			  'pinterest'	 => esc_html__('Pinterest', 'maaya'),
			  'reddit'		 => esc_html__('Reddit', 'maaya'),
			  'rss'		 	 => esc_html__('RSS', 'maaya'),
			  'skype'		 => esc_html__('Skype', 'maaya'),
			  'stumbleupon'	 => esc_html__('Stumbleupon', 'maaya'),
			  'tumblr'		 => esc_html__('Tumblr', 'maaya'),
			  'twitter'		 => esc_html__('Twitter', 'maaya'),
			  'viadeo'		 => esc_html__('Viadeo', 'maaya'),
			  'vimeo'		 => esc_html__('Vimeo', 'maaya'),
			  'yahoo'		 => esc_html__('Yahoo', 'maaya'),
			  'youtube'		 => esc_html__('Youtube', 'maaya'),
			),
			'class'        => 'chosen',
			'default'      => 'delicious',
		  ),

		  array(
			'id'          => 'sociable_fields_url',
			'type'        => 'text',
			'title'       => esc_html__('Enter URL', 'maaya')
		  ),
		)
	  ),

   ),
);

// -----------------------------------------
// Hook Options
// -----------------------------------------
$options[]      = array(
  'name'        => 'hook_options',
  'title'       => esc_html__('Hooks', 'maaya'),
  'icon'        => 'fa fa-paperclip',

  'fields'      => array(

	  array(
		'type'    => 'subheading',
		'content' => esc_html__( "Top Hook", 'maaya' ),
	  ),

	  array(
		'id'  	=> 'enable-top-hook',
		'type'  => 'switcher',
		'title' => esc_html__('Enable Top Hook', 'maaya'),
		'info'	=> esc_html__("YES! to enable top hook.", 'maaya')
	  ),

	  array(
		'id'  		 => 'top-hook',
		'type'  	 => 'textarea',
		'title' 	 => esc_html__('Top Hook', 'maaya'),
		'info'		 => esc_html__('Paste your top hook, Executes after the opening &lt;body&gt; tag.', 'maaya')
	  ),

	  array(
		'type'    => 'subheading',
		'content' => esc_html__( "Content Before Hook", 'maaya' ),
	  ),

	  array(
		'id'  	=> 'enable-content-before-hook',
		'type'  => 'switcher',
		'title' => esc_html__('Enable Content Before Hook', 'maaya'),
		'info'	=> esc_html__("YES! to enable content before hook.", 'maaya')
	  ),

	  array(
		'id'  		 => 'content-before-hook',
		'type'  	 => 'textarea',
		'title' 	 => esc_html__('Content Before Hook', 'maaya'),
		'info'		 => esc_html__('Paste your content before hook, Executes before the opening &lt;#primary&gt; tag.', 'maaya')
	  ),

	  array(
		'type'    => 'subheading',
		'content' => esc_html__( "Content After Hook", 'maaya' ),
	  ),

	  array(
		'id'  	=> 'enable-content-after-hook',
		'type'  => 'switcher',
		'title' => esc_html__('Enable Content After Hook', 'maaya'),
		'info'	=> esc_html__("YES! to enable content after hook.", 'maaya')
	  ),

	  array(
		'id'  		 => 'content-after-hook',
		'type'  	 => 'textarea',
		'title' 	 => esc_html__('Content After Hook', 'maaya'),
		'info'		 => esc_html__('Paste your content after hook, Executes after the closing &lt;/#main&gt; tag.', 'maaya')
	  ),

	  array(
		'type'    => 'subheading',
		'content' => esc_html__( "Bottom Hook", 'maaya' ),
	  ),

	  array(
		'id'  	=> 'enable-bottom-hook',
		'type'  => 'switcher',
		'title' => esc_html__('Enable Bottom Hook', 'maaya'),
		'info'	=> esc_html__("YES! to enable bottom hook.", 'maaya')
	  ),

	  array(
		'id'  		 => 'bottom-hook',
		'type'  	 => 'textarea',
		'title' 	 => esc_html__('Bottom Hook', 'maaya'),
		'info'		 => esc_html__('Paste your bottom hook, Executes after the closing &lt;/body&gt; tag.', 'maaya')
	  ),
	  
	  array(
		'id'  	=> 'enable-analytics-code',
		'type'  => 'switcher',
		'title' => esc_html__('Enable Tracking Code', 'maaya'),
		'info'	=> esc_html__("YES! to enable site tracking code.", 'maaya')
	  ),

	  array(
		'id'  		 => 'analytics-code',
		'type'  	 => 'textarea',
		'title' 	 => esc_html__('Google Analytics Tracking Code', 'maaya'),
		'info'		 => esc_html__('Either enter your Google tracking id (UA-XXXXX-X). If you want to offer your visitors the option to stop being tracked you can place the shortcode [dt_sc_privacy_google_tracking] somewhere on your site', 'maaya')
	  ),

   ),
);

// ------------------------------
// backup                       
// ------------------------------
$options[]   = array(
  'name'     => 'backup_section',
  'title'    => esc_html__('Backup', 'maaya'),
  'icon'     => 'fa fa-shield',
  'fields'   => array(

    array(
      'type'    => 'notice',
      'class'   => 'warning',
      'content' => esc_html__('You can save your current options. Download a Backup and Import.', 'maaya')
    ),

    array(
      'type'    => 'backup',
    ),

  )
);

// ------------------------------
// license
// ------------------------------
$options[]   = array(
  'name'     => 'theme_version',
  'title'    => constant('MAAYA_THEME_NAME').esc_html__(' Log', 'maaya'),
  'icon'     => 'fa fa-info-circle',
  'fields'   => array(

    array(
      'type'    => 'heading',
      'content' => constant('MAAYA_THEME_NAME').esc_html__(' Theme Change Log', 'maaya')
    ),
    array(
      'type'    => 'content',
			'content' => '<pre>

2022.11.26 - version 2.6
* Compatible with WordPress 6.1.1
* Compatible with latest WooCommerce versions
* Compatible with PHP 8.1 version
* Updated: All premium plugins

2022.08.18 - version 2.5
* Compatible with WordPress 6.0.1
* Compatible with the latest WooCommerce plugin
* Updated: All premium plugins
	
2021.08.27 - version 2.4
* Compatible with wordpress 5.8

2021.01.22 - version 2.3
* Compatible with wordpress 5.6
* Some design issues updated
* Updated: All premium plugins

2020.12.02 - version 2.2
* Latest jQuery fixes updated
* Updated: All premium plugins

2020.08.13 - version 2.1
* Compatible with wordpress 5.5			

2020.08.04 - version 2.0

* Updated: Envato Theme check
* Updated: sanitize_text_field added
* Updated: All wordpress theme standards
* Updated: All premium plugins

2020.07.03 - version 1.9

* Compatible with wordpress 5.4.2
* Updated: Some design tweaks
* Updated: Activating another theme causes error
* Updated: All premium plugins
* Updated: Post Likes and Views display issue
* Updated: Related article display issue
* Updated: Sidebar layout issue

2020.02.01 - version 1.8

* Compatible with wordpress 5.3.2
* Updated: All premium plugins
* Updated: All wordpress theme standards
* Updated: Privacy and Cookies concept

* Fixed: Privacy Button Issue

* Improved: Revisions options added for all custom posts

2019.11.18 - version 1.7
* Compatible with wordpress 5.3
* Updated: All wordpress theme standards
* Updated: All premium plugins
* Updated: Revisions added to all custom post types
* Updated: Gutenberg editor support for custom post types
* Updated: Link for phone number module
* Updated: Online documentation link, check readme file

* Fixed: Customizer logo option
* Fixed: Google Analytics issue
* Fixed: Mailchimp email client issue
* Fixed: Gutenberg check for old wordpress version
* Fixed: Edit with Visual Composer for portfolio
* Fixed: Header & Footer wpml option
* Fixed: Site title color
* Fixed: Privacy popup bg color
* Fixed: 404 page scrolling issue

* Improved: Single product breadcrumb section
* Improved: Tags taxonomy added for portfolio
* Improved: Woocommerce cart module added with custom class option

* New: Whatsapp Shortcode

2019.05.16 - version 1.6
 * Gutenberg Latest update compatible
 * Portfolio Video option
 * Coming Soon page fix
 * Portfolio archive page breadcrumb fix
 * Mega menu image fix
 * GDPR product single page fix
 * Codestar framework update
 * Wpml xml file updated
 * disable options for likes and views in single post page
 * Easy Social Share Buttons for WordPress included
 * Updated latest version of all third party plugins
 * Some design tweaks

2019.01.24 - version 1.5
 * Gutenberg compatible
 * Latest WordPress version 5.0.3 compatible
 * Updated latest version of all third party plugins
 * Some design tweaks

2018.10.30 - version 1.4
 * Gutenberg plugin compatible
 * Latest wordpress version 4.9.8 compatible
 * Updated latest version of all third party plugins
 * Updated documentation
 
2018.07.26 - version 1.3
 * GDPR Compliant update in comment form, mailchimp form etc.
 * Packed with - Layer Slider 6.7.6
 * Packed with - Revolution Slider 5.4.8
 * Packed with - WPBakery Page Builder 5.5.2
 * Packed with - Ultimate Addons for Visual Composer 3.16.24
 * Packed with - Envato Market 2.0.0
 * Fix - Option for change the site title color
 * Fix - Add target attribute for social media
 * Fix - Bulk plugins install issue
 * Fix - Unyson Page Builder Conflict
 * Fix - Twitter feeds links issue
 * Fix - Iphone sidebar issue
 * Updated language files

2018.03.02 - version 1.2
 * Two new home pages added
 * Few design tweaks updated
 * Unyson Dummy content Updated

2018.02.20 - version 1.1
 * Optimized Dummy Content Updated

2018.02.15 - version 1.0
 * First release!  </pre>',
    ),

  )
);

// ------------------------------
// Seperator
// ------------------------------
$options[] = array(
  'name'   => 'seperator_1',
  'title'  => esc_html__('Plugin Options', 'maaya'),
  'icon'   => 'fa fa-plug'
);


CSFramework::instance( $settings, $options );