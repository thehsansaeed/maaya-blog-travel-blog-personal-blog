<?php
add_action( 'wp_enqueue_scripts', 'maaya_child_enqueue_styles', 100 );
function maaya_child_enqueue_styles() {
    wp_enqueue_style( 'maaya-parent', get_template_directory_uri() . '/style.css' );
}
?>